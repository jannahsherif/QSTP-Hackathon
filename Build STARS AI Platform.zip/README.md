
  # Build STARS AI Platform

  This is a code bundle for Build STARS AI Platform. The original project is available at https://www.figma.com/design/MiDiAELqkTI3Y3ETvfrduB/Build-STARS-AI-Platform.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  