import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { LandingPage } from "./components/LandingPage";
import { Sidebar, type ModuleId } from "./components/Sidebar";
import { AudienceDigitalTwin } from "./components/AudienceDigitalTwin";
import { FlightSimulator } from "./components/FlightSimulator";
import { ViralDNAAnalyzer } from "./components/ViralDNAAnalyzer";
import { AlgorithmDecoder } from "./components/AlgorithmDecoder";
import { MissionControlDashboard } from "./components/MissionControlDashboard";
import { AICampaignCopilot } from "./components/AICampaignCopilot";
import { ParticleField } from "./components/ParticleField";

const MODULES = [
  AudienceDigitalTwin,
  FlightSimulator,
  ViralDNAAnalyzer,
  AlgorithmDecoder,
  MissionControlDashboard,
  AICampaignCopilot,
];

export default function App() {
  const [view, setView] = useState<"landing" | "app">("landing");
  const [activeModule, setActiveModule] = useState<ModuleId>(4); // default to Mission Control
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);

  const ActiveModule = MODULES[activeModule];

  return (
    <div
      className="w-full h-full overflow-hidden"
      style={{ background: "#020817", fontFamily: "Outfit, sans-serif" }}
    >
      <AnimatePresence mode="wait">
        {view === "landing" ? (
          <motion.div
            key="landing"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0, scale: 0.98 }}
            transition={{ duration: 0.5 }}
            className="w-full h-full"
          >
            <LandingPage onEnter={() => setView("app")} />
          </motion.div>
        ) : (
          <motion.div
            key="app"
            initial={{ opacity: 0, scale: 1.02 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.6, ease: "easeOut" }}
            className="w-full h-full flex relative overflow-hidden"
          >
            {/* Global ambient particles (subtle in app) */}
            <div className="absolute inset-0 pointer-events-none" style={{ zIndex: 0, opacity: 0.3 }}>
              <ParticleField count={40} />
            </div>

            {/* Sidebar */}
            <div className="relative flex-shrink-0" style={{ zIndex: 10 }}>
              <Sidebar
                active={activeModule}
                onChange={setActiveModule}
                collapsed={sidebarCollapsed}
                onToggle={() => setSidebarCollapsed((v) => !v)}
              />
            </div>

            {/* Main content area */}
            <div className="flex-1 relative overflow-hidden" style={{ zIndex: 5 }}>
              {/* Background glow per module */}
              <div
                className="absolute inset-0 pointer-events-none"
                style={{
                  background: [
                    "radial-gradient(ellipse 60% 40% at 70% 30%, rgba(245,158,11,0.04) 0%, transparent 60%)",
                    "radial-gradient(ellipse 60% 40% at 60% 40%, rgba(59,130,246,0.05) 0%, transparent 60%)",
                    "radial-gradient(ellipse 60% 40% at 50% 50%, rgba(236,72,153,0.04) 0%, transparent 60%)",
                    "radial-gradient(ellipse 60% 40% at 60% 30%, rgba(139,92,246,0.05) 0%, transparent 60%)",
                    "radial-gradient(ellipse 60% 40% at 50% 30%, rgba(16,185,129,0.04) 0%, transparent 60%)",
                    "radial-gradient(ellipse 60% 40% at 50% 40%, rgba(6,182,212,0.04) 0%, transparent 60%)",
                  ][activeModule],
                }}
              />

              <AnimatePresence mode="wait">
                <motion.div
                  key={activeModule}
                  initial={{ opacity: 0, x: 20, filter: "blur(4px)" }}
                  animate={{ opacity: 1, x: 0, filter: "blur(0px)" }}
                  exit={{ opacity: 0, x: -20, filter: "blur(4px)" }}
                  transition={{ duration: 0.3, ease: "easeOut" }}
                  className="w-full h-full"
                >
                  <ActiveModule />
                </motion.div>
              </AnimatePresence>
            </div>

            {/* Scanline overlay */}
            <div
              className="absolute inset-0 pointer-events-none"
              style={{
                backgroundImage: "repeating-linear-gradient(0deg, transparent, transparent 2px, rgba(0,0,0,0.015) 2px, rgba(0,0,0,0.015) 4px)",
                zIndex: 20,
              }}
            />
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
