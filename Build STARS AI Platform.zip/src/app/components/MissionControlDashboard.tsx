import { useState, useEffect } from "react";
import { motion } from "motion/react";
import { Activity, TrendingUp, Users, Eye, Heart, Share2, Zap, Globe2, Target, Award } from "lucide-react";
import { AreaChart, Area, BarChart, Bar, LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from "recharts";

const generateTimeSeries = (base: number, variance: number, points: number) =>
  Array.from({ length: points }, (_, i) => ({
    t: i,
    v: Math.round(base + (Math.random() - 0.4) * variance + i * (base * 0.008)),
  }));

const LIVE_DATA = {
  reach: generateTimeSeries(45000, 8000, 24),
  engagement: generateTimeSeries(8.2, 2, 24),
  followers: generateTimeSeries(2300000, 50000, 12),
};

const PLATFORM_BREAKDOWN = [
  { name: "Instagram", value: 38, color: "#ec4899" },
  { name: "TikTok", value: 28, color: "#06b6d4" },
  { name: "YouTube", value: 18, color: "#ef4444" },
  { name: "LinkedIn", value: 10, color: "#3b82f6" },
  { name: "X", value: 6, color: "#94a3b8" },
];

const RECENT_POSTS = [
  {
    id: 1,
    platform: "TikTok",
    platformColor: "#06b6d4",
    content: "Dr. Sarah's water purification breakthrough — Desert beetle inspired design",
    time: "2h ago",
    reach: "182K",
    likes: "23.4K",
    comments: "4.2K",
    score: 94,
    trending: true,
  },
  {
    id: 2,
    platform: "Instagram",
    platformColor: "#ec4899",
    content: "Stars of Science Season 15 finalist reveal — Reel",
    time: "5h ago",
    reach: "67K",
    likes: "12.3K",
    comments: "891",
    score: 87,
    trending: false,
  },
  {
    id: 3,
    platform: "YouTube",
    platformColor: "#ef4444",
    content: "Lab Behind-the-Scenes: AI Prosthetics Innovation",
    time: "1d ago",
    reach: "95K",
    likes: "8.7K",
    comments: "1.24K",
    score: 82,
    trending: false,
  },
  {
    id: 4,
    platform: "LinkedIn",
    platformColor: "#3b82f6",
    content: "Celebrating Arab world innovators — Impact Report 2025",
    time: "2d ago",
    reach: "28K",
    likes: "3.2K",
    comments: "560",
    score: 76,
    trending: false,
  },
];

const ALERTS = [
  { type: "viral", text: "TikTok post entering viral trajectory — 180K views in 2h", color: "#10b981", icon: "🚀" },
  { type: "opportunity", text: "Instagram algorithm window open — optimal posting time: NOW", color: "#f59e0b", icon: "⚡" },
  { type: "trend", text: "#ArabInnovation trending in MENA — ride this wave", color: "#8b5cf6", icon: "📈" },
];

function StatCard({
  label, value, delta, deltaPositive, icon: Icon, color, suffix = "",
}: {
  label: string; value: string; delta: string; deltaPositive: boolean; icon: React.ElementType; color: string; suffix?: string;
}) {
  return (
    <motion.div
      whileHover={{ y: -2, scale: 1.01 }}
      className="p-5 rounded-2xl"
      style={{ background: "rgba(15,32,64,0.6)", border: "1px solid rgba(59,130,246,0.1)" }}
    >
      <div className="flex items-start justify-between mb-4">
        <div
          className="w-10 h-10 rounded-xl flex items-center justify-center"
          style={{ background: `${color}15` }}
        >
          <Icon className="w-5 h-5" style={{ color }} />
        </div>
        <span
          className="px-2 py-1 rounded-lg text-xs"
          style={{
            background: deltaPositive ? "rgba(16,185,129,0.1)" : "rgba(239,68,68,0.1)",
            color: deltaPositive ? "#10b981" : "#ef4444",
            fontFamily: "JetBrains Mono, monospace",
            fontSize: 10,
          }}
        >
          {delta}
        </span>
      </div>
      <div style={{ fontFamily: "Outfit, sans-serif", fontSize: 26, fontWeight: 900, color: "#e2e8f0", letterSpacing: "-0.02em", lineHeight: 1 }}>
        {value}{suffix}
      </div>
      <div style={{ fontFamily: "JetBrains Mono, monospace", fontSize: 9, color: "#64748b", marginTop: 4, letterSpacing: "0.08em" }}>
        {label.toUpperCase()}
      </div>
    </motion.div>
  );
}

function LiveDot() {
  return (
    <span className="relative flex w-2.5 h-2.5">
      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-60" />
      <span className="relative inline-flex rounded-full w-2.5 h-2.5 bg-emerald-400" />
    </span>
  );
}

export function MissionControlDashboard() {
  const [liveReach, setLiveReach] = useState(182400);
  const [liveEngagement, setLiveEngagement] = useState(8.4);
  const [ticker, setTicker] = useState(0);

  useEffect(() => {
    const iv = setInterval(() => {
      setLiveReach((v) => v + Math.round(Math.random() * 150 - 20));
      setLiveEngagement((v) => Math.max(7, Math.min(10, v + (Math.random() - 0.45) * 0.1)));
      setTicker((t) => t + 1);
    }, 1800);
    return () => clearInterval(iv);
  }, []);

  return (
    <div className="h-full flex flex-col overflow-hidden">
      {/* Header */}
      <div className="flex items-center justify-between px-6 py-4 border-b flex-shrink-0" style={{ borderColor: "rgba(59,130,246,0.1)" }}>
        <div>
          <div style={{ fontFamily: "JetBrains Mono, monospace", fontSize: 10, color: "#10b981", letterSpacing: "0.15em" }}>
            MODULE 05 · REAL-TIME ANALYTICS
          </div>
          <h2 style={{ fontFamily: "Outfit, sans-serif", fontSize: 22, fontWeight: 800, color: "#e2e8f0", letterSpacing: "-0.02em" }}>
            Mission Control
          </h2>
        </div>
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2 px-3 py-1.5 rounded-full" style={{ background: "rgba(16,185,129,0.1)", border: "1px solid rgba(16,185,129,0.2)" }}>
            <LiveDot />
            <span style={{ fontFamily: "JetBrains Mono, monospace", fontSize: 10, color: "#10b981" }}>LIVE · 5 PLATFORMS</span>
          </div>
          <div>
            <div style={{ fontFamily: "Outfit, sans-serif", fontSize: 18, fontWeight: 800, color: "#e2e8f0" }}>
              {liveReach.toLocaleString()}
            </div>
            <div style={{ fontFamily: "JetBrains Mono, monospace", fontSize: 9, color: "#64748b" }}>LIVE REACH</div>
          </div>
        </div>
      </div>

      {/* Alerts */}
      <div className="flex gap-3 px-6 py-3 border-b overflow-x-auto flex-shrink-0" style={{ borderColor: "rgba(59,130,246,0.1)" }}>
        {ALERTS.map((alert, i) => (
          <div
            key={i}
            className="flex items-center gap-2.5 px-4 py-2.5 rounded-xl flex-shrink-0"
            style={{
              background: `${alert.color}08`,
              border: `1px solid ${alert.color}25`,
              minWidth: 280,
            }}
          >
            <span style={{ fontSize: 16 }}>{alert.icon}</span>
            <span style={{ fontFamily: "Outfit, sans-serif", fontSize: 12, color: "#94a3b8", lineHeight: 1.4 }}>{alert.text}</span>
          </div>
        ))}
      </div>

      <div className="flex-1 overflow-y-auto p-6 space-y-5">
        {/* KPI grid */}
        <div className="grid grid-cols-4 gap-4">
          <StatCard label="Total Audience" value="2.31M" delta="+18.2%" deltaPositive icon={Users} color="#3b82f6" />
          <StatCard label="24h Reach" value="413K" delta="+31%" deltaPositive icon={Eye} color="#8b5cf6" />
          <StatCard label="Avg Engagement" value={liveEngagement.toFixed(1)} suffix="%" delta="+2.1%" deltaPositive icon={Heart} color="#ec4899" />
          <StatCard label="Content Score" value="87" delta="+5pts" deltaPositive icon={Award} color="#f59e0b" />
        </div>

        <div className="grid grid-cols-[1fr_280px] gap-5">
          {/* Reach over time */}
          <div
            className="p-5 rounded-2xl"
            style={{ background: "rgba(15,32,64,0.5)", border: "1px solid rgba(59,130,246,0.08)" }}
          >
            <div className="flex items-center justify-between mb-4">
              <div style={{ fontFamily: "JetBrains Mono, monospace", fontSize: 10, color: "#64748b", letterSpacing: "0.1em" }}>
                24H REACH TRAJECTORY
              </div>
              <LiveDot />
            </div>
            <div className="h-44">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={LIVE_DATA.reach} margin={{ top: 4, right: 0, left: -30, bottom: 0 }}>
                  <defs>
                    <linearGradient id="reachGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="#3b82f6" stopOpacity={0.4} />
                      <stop offset="100%" stopColor="#3b82f6" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <XAxis dataKey="t" hide />
                  <YAxis tick={{ fontSize: 9, fontFamily: "JetBrains Mono", fill: "#475569" }} />
                  <Tooltip
                    contentStyle={{ background: "#0a1628", border: "1px solid rgba(59,130,246,0.2)", borderRadius: 8, fontSize: 11, fontFamily: "JetBrains Mono" }}
                    formatter={(v: number) => [v.toLocaleString(), "Reach"]}
                  />
                  <Area type="monotone" dataKey="v" stroke="#3b82f6" fill="url(#reachGrad)" strokeWidth={2} />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Platform breakdown */}
          <div
            className="p-5 rounded-2xl"
            style={{ background: "rgba(15,32,64,0.5)", border: "1px solid rgba(59,130,246,0.08)" }}
          >
            <div className="mb-4" style={{ fontFamily: "JetBrains Mono, monospace", fontSize: 10, color: "#64748b", letterSpacing: "0.1em" }}>
              PLATFORM SPLIT
            </div>
            <div className="h-32 flex items-center justify-center">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={PLATFORM_BREAKDOWN}
                    dataKey="value"
                    cx="50%"
                    cy="50%"
                    innerRadius={36}
                    outerRadius={56}
                    strokeWidth={0}
                  >
                    {PLATFORM_BREAKDOWN.map((entry, i) => (
                      <Cell key={i} fill={entry.color} opacity={0.85} />
                    ))}
                  </Pie>
                </PieChart>
              </ResponsiveContainer>
            </div>
            <div className="space-y-2 mt-2">
              {PLATFORM_BREAKDOWN.map((p) => (
                <div key={p.name} className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="w-2 h-2 rounded-full" style={{ background: p.color }} />
                    <span style={{ fontFamily: "Outfit, sans-serif", fontSize: 12, color: "#94a3b8" }}>{p.name}</span>
                  </div>
                  <span style={{ fontFamily: "JetBrains Mono, monospace", fontSize: 11, color: p.color }}>{p.value}%</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Engagement over time */}
        <div
          className="p-5 rounded-2xl"
          style={{ background: "rgba(15,32,64,0.5)", border: "1px solid rgba(59,130,246,0.08)" }}
        >
          <div className="flex items-center justify-between mb-4">
            <div style={{ fontFamily: "JetBrains Mono, monospace", fontSize: 10, color: "#64748b", letterSpacing: "0.1em" }}>
              ENGAGEMENT RATE vs INDUSTRY AVERAGE
            </div>
            <div className="flex items-center gap-4 text-xs" style={{ fontFamily: "JetBrains Mono, monospace" }}>
              <span className="flex items-center gap-1.5"><span className="w-3 h-0.5 rounded bg-pink-400 inline-block" />Your Content</span>
              <span className="flex items-center gap-1.5"><span className="w-3 h-0.5 rounded bg-slate-600 inline-block" />Industry Avg</span>
            </div>
          </div>
          <div className="h-36">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart
                data={LIVE_DATA.engagement.map((d, i) => ({ ...d, avg: 3.2 + Math.sin(i * 0.4) * 0.3 }))}
                margin={{ top: 4, right: 0, left: -30, bottom: 0 }}
              >
                <XAxis dataKey="t" hide />
                <YAxis tick={{ fontSize: 9, fontFamily: "JetBrains Mono", fill: "#475569" }} unit="%" />
                <Tooltip
                  contentStyle={{ background: "#0a1628", border: "1px solid rgba(59,130,246,0.2)", borderRadius: 8, fontSize: 11, fontFamily: "JetBrains Mono" }}
                  formatter={(v: number) => [`${v.toFixed(1)}%`, ""]}
                />
                <Line type="monotone" dataKey="v" stroke="#ec4899" strokeWidth={2} dot={false} />
                <Line type="monotone" dataKey="avg" stroke="#475569" strokeWidth={1} strokeDasharray="4 4" dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Recent posts */}
        <div>
          <div className="mb-3" style={{ fontFamily: "JetBrains Mono, monospace", fontSize: 10, color: "#64748b", letterSpacing: "0.1em" }}>
            RECENT CONTENT PERFORMANCE
          </div>
          <div className="space-y-3">
            {RECENT_POSTS.map((post, i) => (
              <motion.div
                key={post.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.06 }}
                className="p-4 rounded-2xl flex items-center gap-4"
                style={{ background: "rgba(15,32,64,0.5)", border: "1px solid rgba(59,130,246,0.08)" }}
              >
                <div
                  className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 text-sm font-black"
                  style={{ background: `${post.platformColor}15`, color: post.platformColor, fontFamily: "Outfit, sans-serif" }}
                >
                  {post.platform[0]}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-0.5">
                    <span style={{ fontFamily: "Outfit, sans-serif", fontSize: 13, fontWeight: 700, color: post.platformColor }}>{post.platform}</span>
                    {post.trending && (
                      <span className="px-2 py-0.5 rounded-full" style={{ background: "rgba(16,185,129,0.1)", border: "1px solid rgba(16,185,129,0.2)" }}>
                        <span style={{ fontFamily: "JetBrains Mono, monospace", fontSize: 8, color: "#10b981" }}>🚀 TRENDING</span>
                      </span>
                    )}
                    <span style={{ fontFamily: "JetBrains Mono, monospace", fontSize: 9, color: "#475569" }}>{post.time}</span>
                  </div>
                  <p className="truncate" style={{ fontFamily: "Outfit, sans-serif", fontSize: 13, color: "#94a3b8" }}>{post.content}</p>
                </div>
                <div className="flex items-center gap-5 flex-shrink-0">
                  <div className="text-center">
                    <div style={{ fontFamily: "Outfit, sans-serif", fontSize: 14, fontWeight: 700, color: "#e2e8f0" }}>{post.reach}</div>
                    <div style={{ fontFamily: "JetBrains Mono, monospace", fontSize: 8, color: "#475569" }}>REACH</div>
                  </div>
                  <div className="text-center">
                    <div style={{ fontFamily: "Outfit, sans-serif", fontSize: 14, fontWeight: 700, color: "#ec4899" }}>{post.likes}</div>
                    <div style={{ fontFamily: "JetBrains Mono, monospace", fontSize: 8, color: "#475569" }}>LIKES</div>
                  </div>
                  <div className="text-center">
                    <div style={{ fontFamily: "Outfit, sans-serif", fontSize: 14, fontWeight: 700, color: "#8b5cf6" }}>{post.comments}</div>
                    <div style={{ fontFamily: "JetBrains Mono, monospace", fontSize: 8, color: "#475569" }}>COMMENTS</div>
                  </div>
                  <div
                    className="w-10 h-10 rounded-full flex items-center justify-center text-sm font-black"
                    style={{
                      background: post.score >= 90 ? "rgba(16,185,129,0.15)" : post.score >= 80 ? "rgba(59,130,246,0.15)" : "rgba(100,116,139,0.15)",
                      border: `2px solid ${post.score >= 90 ? "rgba(16,185,129,0.3)" : post.score >= 80 ? "rgba(59,130,246,0.3)" : "rgba(100,116,139,0.3)"}`,
                      color: post.score >= 90 ? "#10b981" : post.score >= 80 ? "#3b82f6" : "#64748b",
                      fontFamily: "Outfit, sans-serif",
                    }}
                  >
                    {post.score}
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Bottom stats */}
        <div className="grid grid-cols-4 gap-4 pb-2">
          {[
            { label: "Posts This Week", value: "12", sub: "↑4 vs last week", color: "#3b82f6" },
            { label: "Total Interactions", value: "487K", sub: "+28% MoM", color: "#ec4899" },
            { label: "Click-Through Rate", value: "6.8%", sub: "Industry: 2.1%", color: "#10b981" },
            { label: "Share of Voice", value: "34%", sub: "Science media MENA", color: "#f59e0b" },
          ].map((s) => (
            <div
              key={s.label}
              className="p-4 rounded-2xl"
              style={{ background: "rgba(15,32,64,0.4)", border: "1px solid rgba(59,130,246,0.08)" }}
            >
              <div style={{ fontFamily: "Outfit, sans-serif", fontSize: 24, fontWeight: 900, color: s.color, letterSpacing: "-0.02em" }}>
                {s.value}
              </div>
              <div style={{ fontFamily: "JetBrains Mono, monospace", fontSize: 9, color: "#64748b", letterSpacing: "0.05em", marginBottom: 4 }}>
                {s.label.toUpperCase()}
              </div>
              <div style={{ fontFamily: "Outfit, sans-serif", fontSize: 11, color: "#475569" }}>{s.sub}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
