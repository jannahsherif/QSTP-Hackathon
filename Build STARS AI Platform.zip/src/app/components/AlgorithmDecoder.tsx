import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Cpu, ChevronRight, TrendingUp, Clock, Hash, Eye, Zap, AlertTriangle } from "lucide-react";

const PLATFORMS = [
  {
    id: "instagram",
    name: "Instagram",
    emoji: "📸",
    color: "#ec4899",
    score: 84,
    reaction: "Highly Favorable",
    reactionColor: "#10b981",
    algorithm: "Reels-First Distribution Engine",
    summary: "Instagram's algorithm heavily favors Reels and will push your content to the Explore page if it achieves 60%+ retention in the first 3 seconds. Your science content taps into the Education and Innovation interest clusters.",
    factors: [
      { label: "Reel Retention Rate", value: "78%", impact: "high", icon: Eye, color: "#10b981" },
      { label: "Save Rate Signal", value: "12.3%", impact: "high", icon: TrendingUp, color: "#3b82f6" },
      { label: "Share Velocity", value: "Fast (2h)", impact: "medium", icon: Zap, color: "#f59e0b" },
      { label: "Hashtag Power", value: "6/10 match", impact: "medium", icon: Hash, color: "#8b5cf6" },
      { label: "Peak Window", value: "7-9 PM GST", impact: "high", icon: Clock, color: "#06b6d4" },
    ],
    boosts: [
      "Post as a Reel under 60 seconds",
      "Use Arabic + English captions",
      "Pin the most engaging comment in first 10 min",
      "Add Location: Qatar/Dubai for MENA reach",
      "Include 3-5 niche science hashtags",
    ],
    warnings: [
      "Avoid text-heavy thumbnails — reduces Explore reach",
      "Don't post between 11 PM – 6 AM GST",
    ],
    metrics: {
      explore: 72,
      organic: 85,
      paid: 91,
      longevity: 64,
    },
  },
  {
    id: "tiktok",
    name: "TikTok",
    emoji: "🎵",
    color: "#06b6d4",
    score: 92,
    reaction: "Viral Candidate",
    reactionColor: "#10b981",
    algorithm: "Interest Graph + Completion Rate Engine",
    summary: "TikTok's For You Page uses completion rate, rewatch rate, and early engagement signals. Science content with strong narrative hooks performs 3.2x above average in the Education vertical.",
    factors: [
      { label: "Completion Rate", value: "Predicted: 71%", impact: "high", icon: Eye, color: "#10b981" },
      { label: "Rewatch Signal", value: "High (hook quality)", impact: "high", icon: TrendingUp, color: "#3b82f6" },
      { label: "Sound Strategy", value: "Original + Trending", impact: "medium", icon: Zap, color: "#f59e0b" },
      { label: "Duet/Stitch", value: "Enable both", impact: "medium", icon: Hash, color: "#8b5cf6" },
      { label: "Posting Cadence", value: "2-3x/week optimal", impact: "low", icon: Clock, color: "#06b6d4" },
    ],
    boosts: [
      "First 3 seconds must be your strongest visual",
      "Use trending audio relevant to science themes",
      "Enable Stitch — invites expert community replies",
      "Add text overlay subtitles (85% watch muted)",
      "Post at 7-8 PM local time for max FYP push",
    ],
    warnings: [
      "Avoid recycled content from other platforms",
      "Resolution below 1080p significantly reduces reach",
    ],
    metrics: {
      explore: 89,
      organic: 92,
      paid: 88,
      longevity: 71,
    },
  },
  {
    id: "linkedin",
    name: "LinkedIn",
    emoji: "💼",
    color: "#3b82f6",
    score: 76,
    reaction: "Strong B2B Reach",
    reactionColor: "#f59e0b",
    algorithm: "Professional Relevance + Dwell Time",
    summary: "LinkedIn's algorithm rewards content that keeps users on the platform. Science innovation content receives amplification from LinkedIn Editorial and is distributed to university alumni and R&D professional networks.",
    factors: [
      { label: "Dwell Time Score", value: "4.2 min avg", impact: "high", icon: Eye, color: "#10b981" },
      { label: "Professional Tags", value: "7 relevant skills", impact: "high", icon: Hash, color: "#8b5cf6" },
      { label: "Comment Depth", value: "Target: 3+ lines", impact: "high", icon: TrendingUp, color: "#3b82f6" },
      { label: "Early Velocity", value: "First 3hrs critical", impact: "high", icon: Clock, color: "#f59e0b" },
      { label: "Creator Mode", value: "Active (boost)", impact: "medium", icon: Zap, color: "#06b6d4" },
    ],
    boosts: [
      "Start post with a bold claim or question",
      "Tag Qatar Foundation and QSTP officially",
      "Use 'document carousel' format for innovation steps",
      "Respond to every comment within first 2 hours",
      "Cross-post to relevant LinkedIn Groups",
    ],
    warnings: [
      "External links in post body reduce reach by ~40%",
      "Avoid promotional language in first paragraph",
    ],
    metrics: {
      explore: 68,
      organic: 76,
      paid: 85,
      longevity: 82,
    },
  },
  {
    id: "youtube",
    name: "YouTube",
    emoji: "▶️",
    color: "#ef4444",
    score: 88,
    reaction: "Strong Long-Term Play",
    reactionColor: "#10b981",
    algorithm: "Watch Time + Click-Through Rate Engine",
    summary: "YouTube's algorithm prioritizes watch time and click-through rate. Science content in the 8-15 minute range consistently outperforms shorts in the Education category, with 60% of views coming after 30 days.",
    factors: [
      { label: "CTR Target", value: "> 6% for trending", impact: "high", icon: Eye, color: "#10b981" },
      { label: "Watch Time", value: "8-12 min optimal", impact: "high", icon: Clock, color: "#f59e0b" },
      { label: "Chapter Markers", value: "Boost retention", impact: "medium", icon: TrendingUp, color: "#3b82f6" },
      { label: "End Screen CTA", value: "Sub rate: +23%", impact: "medium", icon: Zap, color: "#8b5cf6" },
      { label: "Thumbnail Quality", value: "Face + text formula", impact: "high", icon: Hash, color: "#06b6d4" },
    ],
    boosts: [
      "Thumbnail formula: Face + Number + Emotion",
      "First 30 seconds = value delivery, no intro fluff",
      "Add chapter markers every 2-3 minutes",
      "Subtitle file in Arabic + English",
      "Pin a comment with key timestamps",
    ],
    warnings: [
      "CTR below 3% triggers algorithm suppression",
      "Avoid uploading more than once per day",
    ],
    metrics: {
      explore: 82,
      organic: 88,
      paid: 79,
      longevity: 94,
    },
  },
  {
    id: "x",
    name: "X (Twitter)",
    emoji: "✕",
    color: "#e2e8f0",
    score: 79,
    reaction: "Good for Conversations",
    reactionColor: "#f59e0b",
    algorithm: "Engagement Velocity + Network Amplification",
    summary: "X prioritizes content that sparks rapid engagement from users with high follower counts. Science threads with controversial or surprising angles get amplified by tech and innovation communities.",
    factors: [
      { label: "Reply Velocity", value: "First 30 min critical", impact: "high", icon: Clock, color: "#10b981" },
      { label: "Retweet Network", value: "Target verified accounts", impact: "high", icon: TrendingUp, color: "#3b82f6" },
      { label: "Thread Format", value: "7-12 tweets optimal", impact: "medium", icon: Zap, color: "#f59e0b" },
      { label: "Media Attachment", value: "Video > Image > Text", impact: "medium", icon: Eye, color: "#8b5cf6" },
      { label: "Quote Tweet", value: "Generates sub-threads", impact: "high", icon: Hash, color: "#06b6d4" },
    ],
    boosts: [
      "Open thread with a surprising data point",
      "Tag 2-3 science journalists in thread",
      "Use the 'comma hook' — 'Story 1/7'",
      "Reply to your own thread with media",
      "Launch Monday-Wednesday 11 AM GST",
    ],
    warnings: [
      "External links in opening tweet reduce reach",
      "Avoid content that can be easily misquoted",
    ],
    metrics: {
      explore: 71,
      organic: 79,
      paid: 82,
      longevity: 58,
    },
  },
];

function MetricBar({ label, value, color }: { label: string; value: number; color: string }) {
  return (
    <div>
      <div className="flex justify-between mb-1.5">
        <span style={{ fontFamily: "Outfit, sans-serif", fontSize: 12, color: "#94a3b8" }}>{label}</span>
        <span style={{ fontFamily: "JetBrains Mono, monospace", fontSize: 11, color }}>
          {value}%
        </span>
      </div>
      <div className="h-1.5 rounded-full" style={{ background: "rgba(255,255,255,0.05)" }}>
        <motion.div
          initial={{ width: 0 }}
          animate={{ width: `${value}%` }}
          transition={{ duration: 0.8, ease: "easeOut" }}
          className="h-full rounded-full"
          style={{ background: `linear-gradient(90deg, ${color}80, ${color})`, boxShadow: `0 0 6px ${color}50` }}
        />
      </div>
    </div>
  );
}

export function AlgorithmDecoder() {
  const [selected, setSelected] = useState(PLATFORMS[0]);

  return (
    <div className="h-full flex flex-col overflow-hidden">
      {/* Header */}
      <div className="flex items-center justify-between px-6 py-4 border-b flex-shrink-0" style={{ borderColor: "rgba(59,130,246,0.1)" }}>
        <div>
          <div style={{ fontFamily: "JetBrains Mono, monospace", fontSize: 10, color: "#8b5cf6", letterSpacing: "0.15em" }}>
            MODULE 04 · ALGORITHMIC INTELLIGENCE
          </div>
          <h2 style={{ fontFamily: "Outfit, sans-serif", fontSize: 22, fontWeight: 800, color: "#e2e8f0", letterSpacing: "-0.02em" }}>
            Algorithm Decoder
          </h2>
        </div>
        <div
          className="px-4 py-2 rounded-xl flex items-center gap-2"
          style={{ background: "rgba(139,92,246,0.1)", border: "1px solid rgba(139,92,246,0.2)" }}
        >
          <Cpu className="w-4 h-4" style={{ color: "#8b5cf6" }} />
          <span style={{ fontFamily: "JetBrains Mono, monospace", fontSize: 10, color: "#8b5cf6" }}>5 ALGORITHMS DECODED</span>
        </div>
      </div>

      <div className="flex-1 grid grid-cols-[220px_1fr] overflow-hidden">
        {/* Platform selector */}
        <div
          className="flex flex-col gap-2 p-4 border-r overflow-y-auto"
          style={{ borderColor: "rgba(59,130,246,0.1)" }}
        >
          <div className="mb-1" style={{ fontFamily: "JetBrains Mono, monospace", fontSize: 10, color: "#64748b", letterSpacing: "0.1em" }}>
            SELECT PLATFORM
          </div>
          {PLATFORMS.map((p) => (
            <motion.button
              key={p.id}
              onClick={() => setSelected(p)}
              whileHover={{ x: 2 }}
              className="flex items-center gap-3 p-3 rounded-xl text-left transition-all duration-200"
              style={{
                background: selected.id === p.id ? `${p.color}12` : "rgba(15,32,64,0.4)",
                border: `1px solid ${selected.id === p.id ? p.color + "35" : "rgba(59,130,246,0.08)"}`,
              }}
            >
              <span style={{ fontSize: 20 }}>{p.emoji}</span>
              <div className="flex-1 min-w-0">
                <div style={{ fontFamily: "Outfit, sans-serif", fontSize: 13, fontWeight: 700, color: "#e2e8f0" }}>{p.name}</div>
                <div style={{ fontFamily: "JetBrains Mono, monospace", fontSize: 9, color: p.reactionColor }}>{p.reaction}</div>
              </div>
              <div
                className="text-sm font-black flex-shrink-0"
                style={{ fontFamily: "Outfit, sans-serif", color: p.color, minWidth: 24, textAlign: "right" }}
              >
                {p.score}
              </div>
            </motion.button>
          ))}
        </div>

        {/* Main content */}
        <AnimatePresence mode="wait">
          <motion.div
            key={selected.id}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            transition={{ duration: 0.25 }}
            className="overflow-y-auto p-6 space-y-5"
          >
            {/* Platform overview */}
            <div
              className="p-6 rounded-2xl"
              style={{
                background: `${selected.color}08`,
                border: `1px solid ${selected.color}20`,
              }}
            >
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center gap-3">
                  <div
                    className="w-14 h-14 rounded-2xl flex items-center justify-center text-2xl"
                    style={{ background: `${selected.color}15`, border: `1px solid ${selected.color}30` }}
                  >
                    {selected.emoji}
                  </div>
                  <div>
                    <h3 style={{ fontFamily: "Outfit, sans-serif", fontSize: 22, fontWeight: 800, color: "#e2e8f0" }}>
                      {selected.name}
                    </h3>
                    <div style={{ fontFamily: "JetBrains Mono, monospace", fontSize: 10, color: "#64748b" }}>
                      {selected.algorithm}
                    </div>
                  </div>
                </div>
                <div className="text-right">
                  <div style={{ fontFamily: "Outfit, sans-serif", fontSize: 44, fontWeight: 900, color: selected.color, letterSpacing: "-0.03em", lineHeight: 1 }}>
                    {selected.score}
                  </div>
                  <div
                    className="px-2 py-0.5 rounded-full inline-block mt-1"
                    style={{ background: `${selected.reactionColor}15`, border: `1px solid ${selected.reactionColor}30` }}
                  >
                    <span style={{ fontFamily: "JetBrains Mono, monospace", fontSize: 9, color: selected.reactionColor }}>
                      {selected.reaction.toUpperCase()}
                    </span>
                  </div>
                </div>
              </div>

              <p style={{ fontFamily: "Outfit, sans-serif", fontSize: 14, color: "#94a3b8", lineHeight: 1.7 }}>
                {selected.summary}
              </p>
            </div>

            <div className="grid grid-cols-2 gap-5">
              {/* Key factors */}
              <div
                className="p-5 rounded-2xl"
                style={{ background: "rgba(15,32,64,0.5)", border: "1px solid rgba(59,130,246,0.08)" }}
              >
                <div className="mb-4" style={{ fontFamily: "JetBrains Mono, monospace", fontSize: 10, color: "#64748b", letterSpacing: "0.1em" }}>
                  ALGORITHM SIGNALS
                </div>
                <div className="space-y-3">
                  {selected.factors.map((factor, i) => {
                    const Icon = factor.icon;
                    return (
                      <motion.div
                        key={factor.label}
                        initial={{ opacity: 0, x: -10 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: i * 0.05 }}
                        className="flex items-center gap-3"
                      >
                        <div
                          className="w-8 h-8 rounded-xl flex items-center justify-center flex-shrink-0"
                          style={{ background: `${factor.color}12` }}
                        >
                          <Icon className="w-3.5 h-3.5" style={{ color: factor.color }} />
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center justify-between">
                            <span style={{ fontFamily: "Outfit, sans-serif", fontSize: 13, fontWeight: 600, color: "#e2e8f0" }}>
                              {factor.label}
                            </span>
                            <span
                              className="px-1.5 py-0.5 rounded text-xs"
                              style={{
                                background: factor.impact === "high" ? "rgba(16,185,129,0.1)" : factor.impact === "medium" ? "rgba(245,158,11,0.1)" : "rgba(100,116,139,0.1)",
                                color: factor.impact === "high" ? "#10b981" : factor.impact === "medium" ? "#f59e0b" : "#64748b",
                                fontFamily: "JetBrains Mono, monospace",
                                fontSize: 8,
                                letterSpacing: "0.05em",
                              }}
                            >
                              {factor.impact.toUpperCase()}
                            </span>
                          </div>
                          <div style={{ fontFamily: "JetBrains Mono, monospace", fontSize: 10, color: "#64748b", marginTop: 1 }}>
                            {factor.value}
                          </div>
                        </div>
                      </motion.div>
                    );
                  })}
                </div>
              </div>

              {/* Performance scores */}
              <div
                className="p-5 rounded-2xl"
                style={{ background: "rgba(15,32,64,0.5)", border: "1px solid rgba(59,130,246,0.08)" }}
              >
                <div className="mb-4" style={{ fontFamily: "JetBrains Mono, monospace", fontSize: 10, color: "#64748b", letterSpacing: "0.1em" }}>
                  DISTRIBUTION FORECAST
                </div>
                <div className="space-y-4">
                  <MetricBar label="Explore / FYP Potential" value={selected.metrics.explore} color={selected.color} />
                  <MetricBar label="Organic Reach Score" value={selected.metrics.organic} color="#3b82f6" />
                  <MetricBar label="Paid Amplification" value={selected.metrics.paid} color="#8b5cf6" />
                  <MetricBar label="Content Longevity" value={selected.metrics.longevity} color="#10b981" />
                </div>
              </div>
            </div>

            {/* Boost strategies + Warnings */}
            <div className="grid grid-cols-2 gap-5">
              <div
                className="p-5 rounded-2xl"
                style={{ background: "rgba(16,185,129,0.05)", border: "1px solid rgba(16,185,129,0.12)" }}
              >
                <div className="flex items-center gap-2 mb-4">
                  <Zap className="w-4 h-4" style={{ color: "#10b981" }} />
                  <span style={{ fontFamily: "JetBrains Mono, monospace", fontSize: 10, color: "#10b981", letterSpacing: "0.1em" }}>
                    BOOST STRATEGIES
                  </span>
                </div>
                <ul className="space-y-2.5">
                  {selected.boosts.map((boost, i) => (
                    <motion.li
                      key={i}
                      initial={{ opacity: 0, x: -10 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: i * 0.06 }}
                      className="flex items-start gap-2.5"
                    >
                      <div className="w-4 h-4 rounded-full bg-emerald-400/20 border border-emerald-400/30 flex items-center justify-center flex-shrink-0 mt-0.5 text-emerald-400 text-xs font-bold">
                        {i + 1}
                      </div>
                      <span style={{ fontFamily: "Outfit, sans-serif", fontSize: 13, color: "#94a3b8", lineHeight: 1.5 }}>
                        {boost}
                      </span>
                    </motion.li>
                  ))}
                </ul>
              </div>

              <div
                className="p-5 rounded-2xl"
                style={{ background: "rgba(239,68,68,0.04)", border: "1px solid rgba(239,68,68,0.12)" }}
              >
                <div className="flex items-center gap-2 mb-4">
                  <AlertTriangle className="w-4 h-4" style={{ color: "#ef4444" }} />
                  <span style={{ fontFamily: "JetBrains Mono, monospace", fontSize: 10, color: "#ef4444", letterSpacing: "0.1em" }}>
                    ALGORITHM PENALTIES
                  </span>
                </div>
                <ul className="space-y-3">
                  {selected.warnings.map((w, i) => (
                    <motion.li
                      key={i}
                      initial={{ opacity: 0, x: -10 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: 0.3 + i * 0.06 }}
                      className="flex items-start gap-2.5 p-3 rounded-xl"
                      style={{ background: "rgba(239,68,68,0.06)" }}
                    >
                      <AlertTriangle className="w-3.5 h-3.5 text-red-400 flex-shrink-0 mt-0.5" />
                      <span style={{ fontFamily: "Outfit, sans-serif", fontSize: 13, color: "#94a3b8", lineHeight: 1.5 }}>
                        {w}
                      </span>
                    </motion.li>
                  ))}
                </ul>

                {/* Algorithm pulse */}
                <div className="mt-4 p-3 rounded-xl" style={{ background: "rgba(15,32,64,0.4)", border: "1px solid rgba(59,130,246,0.08)" }}>
                  <div style={{ fontFamily: "JetBrains Mono, monospace", fontSize: 9, color: "#64748b", marginBottom: 4 }}>
                    ALGORITHM STATUS
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-2 h-2 rounded-full animate-pulse" style={{ background: selected.reactionColor }} />
                    <span style={{ fontFamily: "Outfit, sans-serif", fontSize: 12, color: selected.reactionColor, fontWeight: 600 }}>
                      {selected.reaction} for Science Content
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        </AnimatePresence>
      </div>
    </div>
  );
}
