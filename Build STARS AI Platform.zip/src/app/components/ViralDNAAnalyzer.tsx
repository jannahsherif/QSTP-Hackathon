import { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Dna, Zap, Upload, RotateCcw, ChevronDown } from "lucide-react";

const DNA_METRICS = [
  { id: "innovation", label: "Innovation", score: 87, color: "#8b5cf6", desc: "How novel and groundbreaking the content is perceived to be", icon: "💡" },
  { id: "emotion", label: "Emotion", score: 92, color: "#ec4899", desc: "Emotional resonance and ability to trigger feelings", icon: "❤️" },
  { id: "curiosity", label: "Curiosity Gap", score: 78, color: "#f59e0b", desc: "How effectively the content creates a need to know more", icon: "🔍" },
  { id: "authority", label: "Authority", score: 95, color: "#3b82f6", desc: "Credibility and expertise signal strength", icon: "🏆" },
  { id: "shareability", label: "Shareability", score: 83, color: "#10b981", desc: "Likelihood of audience sharing the content", icon: "🔗" },
  { id: "storytelling", label: "Storytelling", score: 89, color: "#06b6d4", desc: "Narrative structure and story arc quality", icon: "📖" },
];

const SAMPLE_TEXTS = [
  "Meet Dr. Sarah Al-Rashidi, whose solar-powered water purification system could bring clean water to 50 million people in the Arab world. Her breakthrough? A membrane inspired by the humble desert beetle. 🌊",
  "What if a single algorithm could detect cancer 3 years before symptoms appear? Stars of Science finalist Ahmad Karimi has built exactly that — and it's 99.2% accurate.",
  "The robots are here. But not the ones you feared. Stars of Science finalist Nour Hassan built AI-powered prosthetics that respond to nerve signals with 0.04ms latency.",
];

function DNAHelix({ metrics }: { metrics: typeof DNA_METRICS }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const frameRef = useRef<number>(0);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    canvas.width = canvas.offsetWidth;
    canvas.height = canvas.offsetHeight;

    let t = 0;

    const draw = () => {
      frameRef.current = requestAnimationFrame(draw);
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      const w = canvas.width;
      const h = canvas.height;
      const cx = w / 2;
      const segments = 60;
      const amplitude = 50;
      const period = h / 3;

      // Draw two strands
      for (let strand = 0; strand < 2; strand++) {
        const phaseOffset = strand === 0 ? 0 : Math.PI;

        for (let i = 0; i < segments; i++) {
          const y = (i / segments) * h;
          const progress = i / segments;
          const x = cx + amplitude * Math.sin((y / period) * Math.PI * 2 + t + phaseOffset);
          const nextY = ((i + 1) / segments) * h;
          const nextX = cx + amplitude * Math.sin((nextY / period) * Math.PI * 2 + t + phaseOffset);

          const metricIdx = Math.floor(progress * metrics.length);
          const metric = metrics[Math.min(metricIdx, metrics.length - 1)];
          const alpha = 0.6 + 0.4 * Math.sin(progress * Math.PI);

          ctx.beginPath();
          ctx.moveTo(x, y);
          ctx.lineTo(nextX, nextY);
          ctx.strokeStyle = metric.color + Math.round(alpha * 200).toString(16).padStart(2, "0");
          ctx.lineWidth = 2.5;
          ctx.stroke();

          // Glow dots
          if (i % 4 === 0) {
            const dotAlpha = 0.8 + 0.2 * Math.sin(t * 2 + i * 0.3);
            const dotSize = 4 + 2 * ((metric.score - 70) / 30);
            const grd = ctx.createRadialGradient(x, y, 0, x, y, dotSize * 2);
            grd.addColorStop(0, metric.color + "cc");
            grd.addColorStop(1, "transparent");
            ctx.beginPath();
            ctx.arc(x, y, dotSize * 2, 0, Math.PI * 2);
            ctx.fillStyle = grd;
            ctx.fill();
            ctx.beginPath();
            ctx.arc(x, y, dotSize * 0.7, 0, Math.PI * 2);
            ctx.fillStyle = metric.color + Math.round(dotAlpha * 255).toString(16).padStart(2, "0");
            ctx.fill();
          }
        }
      }

      // Cross-bridges (base pairs)
      const bridgeCount = 18;
      for (let i = 0; i < bridgeCount; i++) {
        const y = (i / bridgeCount) * h + (h / bridgeCount / 2);
        const x1 = cx + amplitude * Math.sin((y / period) * Math.PI * 2 + t);
        const x2 = cx + amplitude * Math.sin((y / period) * Math.PI * 2 + t + Math.PI);

        const progress = i / bridgeCount;
        const metricIdx = Math.floor(progress * metrics.length);
        const metric = metrics[Math.min(metricIdx, metrics.length - 1)];

        const bridgeAlpha = 0.4 + 0.3 * Math.sin(t * 1.5 + i * 0.5);
        ctx.beginPath();
        ctx.moveTo(x1, y);
        ctx.lineTo(x2, y);
        ctx.strokeStyle = metric.color + Math.round(bridgeAlpha * 180).toString(16).padStart(2, "0");
        ctx.lineWidth = 1;
        ctx.setLineDash([4, 4]);
        ctx.stroke();
        ctx.setLineDash([]);

        // Label scores on bridges
        if (i % 3 === 0) {
          const midX = (x1 + x2) / 2;
          ctx.fillStyle = metric.color + "99";
          ctx.font = "bold 9px JetBrains Mono";
          ctx.textAlign = "center";
          ctx.fillText(`${metric.score}`, midX, y - 3);
        }
      }

      t += 0.018;
    };
    draw();

    const onResize = () => {
      canvas.width = canvas.offsetWidth;
      canvas.height = canvas.offsetHeight;
    };
    window.addEventListener("resize", onResize);

    return () => {
      cancelAnimationFrame(frameRef.current);
      window.removeEventListener("resize", onResize);
    };
  }, [metrics]);

  return <canvas ref={canvasRef} className="w-full h-full" />;
}

function ScoreRing({ score, color, size = 80 }: { score: number; color: string; size?: number }) {
  const r = size * 0.38;
  const circ = 2 * Math.PI * r;
  const dash = (score / 100) * circ;

  return (
    <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
      <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="rgba(255,255,255,0.06)" strokeWidth={5} />
      <motion.circle
        cx={size / 2}
        cy={size / 2}
        r={r}
        fill="none"
        stroke={color}
        strokeWidth={5}
        strokeDasharray={`${circ}`}
        initial={{ strokeDashoffset: circ }}
        animate={{ strokeDashoffset: circ - dash }}
        transition={{ duration: 1.2, ease: "easeOut" }}
        strokeLinecap="round"
        transform={`rotate(-90 ${size / 2} ${size / 2})`}
        style={{ filter: `drop-shadow(0 0 6px ${color}80)` }}
      />
      <text
        x={size / 2}
        y={size / 2 + 1}
        textAnchor="middle"
        dominantBaseline="middle"
        fill={color}
        style={{ fontFamily: "Outfit, sans-serif", fontSize: size * 0.22, fontWeight: 900 }}
      >
        {score}
      </text>
    </svg>
  );
}

export function ViralDNAAnalyzer() {
  const [text, setText] = useState(SAMPLE_TEXTS[0]);
  const [analyzing, setAnalyzing] = useState(false);
  const [analyzed, setAnalyzed] = useState(true);
  const [selectedMetric, setSelectedMetric] = useState<(typeof DNA_METRICS)[0] | null>(null);
  const [overallScore] = useState(87);

  const analyze = () => {
    setAnalyzing(true);
    setAnalyzed(false);
    setTimeout(() => {
      setAnalyzing(false);
      setAnalyzed(true);
    }, 2200);
  };

  const totalScore = Math.round(DNA_METRICS.reduce((s, m) => s + m.score, 0) / DNA_METRICS.length);

  return (
    <div className="h-full flex flex-col overflow-hidden">
      {/* Header */}
      <div className="flex items-center justify-between px-6 py-4 border-b flex-shrink-0" style={{ borderColor: "rgba(59,130,246,0.1)" }}>
        <div>
          <div style={{ fontFamily: "JetBrains Mono, monospace", fontSize: 10, color: "#ec4899", letterSpacing: "0.15em" }}>
            MODULE 03 · CONTENT INTELLIGENCE
          </div>
          <h2 style={{ fontFamily: "Outfit, sans-serif", fontSize: 22, fontWeight: 800, color: "#e2e8f0", letterSpacing: "-0.02em" }}>
            Viral DNA Analyzer
          </h2>
        </div>
        <div className="flex items-center gap-3">
          <div
            className="px-4 py-2 rounded-full"
            style={{ background: "rgba(16,185,129,0.1)", border: "1px solid rgba(16,185,129,0.2)" }}
          >
            <span style={{ fontFamily: "JetBrains Mono, monospace", fontSize: 10, color: "#10b981" }}>
              VIRAL INDEX: {totalScore}/100
            </span>
          </div>
        </div>
      </div>

      <div className="flex-1 grid grid-cols-[1fr_280px_300px] overflow-hidden">
        {/* Left: Input + metrics */}
        <div className="flex flex-col overflow-y-auto p-6 gap-5">
          {/* Content input */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <span style={{ fontFamily: "JetBrains Mono, monospace", fontSize: 10, color: "#64748b", letterSpacing: "0.1em" }}>
                CONTENT TO ANALYZE
              </span>
              <button
                onClick={() => setText(SAMPLE_TEXTS[Math.floor(Math.random() * SAMPLE_TEXTS.length)])}
                className="flex items-center gap-1.5 text-xs transition-colors"
                style={{ color: "#475569", fontFamily: "JetBrains Mono, monospace", fontSize: 10 }}
              >
                <RotateCcw className="w-3 h-3" />
                LOAD SAMPLE
              </button>
            </div>
            <textarea
              value={text}
              onChange={(e) => setText(e.target.value)}
              rows={4}
              className="w-full rounded-2xl px-4 py-3 outline-none resize-none transition-all"
              style={{
                background: "rgba(15,32,64,0.6)",
                border: "1px solid rgba(59,130,246,0.2)",
                color: "#e2e8f0",
                fontFamily: "Outfit, sans-serif",
                fontSize: 14,
                lineHeight: 1.6,
              }}
              placeholder="Paste your social media post, caption, or script here..."
            />
            <div className="flex items-center justify-between mt-3">
              <span style={{ fontFamily: "JetBrains Mono, monospace", fontSize: 9, color: "#475569" }}>
                {text.length} CHARS · {text.split(" ").filter(Boolean).length} WORDS
              </span>
              <button
                onClick={analyze}
                disabled={analyzing || !text.trim()}
                className="flex items-center gap-2 px-5 py-2.5 rounded-xl transition-all duration-200 hover:scale-105"
                style={{
                  background: analyzing ? "rgba(236,72,153,0.2)" : "linear-gradient(135deg, #ec4899 0%, #8b5cf6 100%)",
                  boxShadow: analyzing ? "none" : "0 0 20px rgba(236,72,153,0.3)",
                  fontFamily: "Outfit, sans-serif",
                  fontSize: 14,
                  fontWeight: 700,
                  color: "#fff",
                  opacity: !text.trim() ? 0.5 : 1,
                }}
              >
                {analyzing ? (
                  <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                ) : (
                  <Dna className="w-4 h-4" />
                )}
                {analyzing ? "Sequencing DNA..." : "Analyze Viral DNA"}
              </button>
            </div>
          </div>

          {/* Metrics grid */}
          <div>
            <div className="mb-3" style={{ fontFamily: "JetBrains Mono, monospace", fontSize: 10, color: "#64748b", letterSpacing: "0.1em" }}>
              DNA SEQUENCE SCORES
            </div>
            <div className="grid grid-cols-2 gap-3">
              <AnimatePresence>
                {DNA_METRICS.map((metric, i) => (
                  <motion.div
                    key={metric.id}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: analyzed ? 1 : 0.3, y: 0 }}
                    transition={{ delay: i * 0.08 }}
                    onClick={() => setSelectedMetric(selectedMetric?.id === metric.id ? null : metric)}
                    className="p-4 rounded-2xl cursor-pointer transition-all duration-200"
                    style={{
                      background: selectedMetric?.id === metric.id ? `${metric.color}12` : "rgba(15,32,64,0.5)",
                      border: `1px solid ${selectedMetric?.id === metric.id ? metric.color + "40" : "rgba(59,130,246,0.08)"}`,
                    }}
                    whileHover={{ y: -2 }}
                  >
                    <div className="flex items-start justify-between mb-3">
                      <div>
                        <span style={{ fontSize: 18 }}>{metric.icon}</span>
                        <div style={{ fontFamily: "Outfit, sans-serif", fontSize: 14, fontWeight: 700, color: "#e2e8f0", marginTop: 2 }}>
                          {metric.label}
                        </div>
                      </div>
                      <ScoreRing score={analyzed ? metric.score : 0} color={metric.color} size={56} />
                    </div>
                    <div className="h-1 rounded-full" style={{ background: "rgba(255,255,255,0.05)" }}>
                      <motion.div
                        initial={{ width: 0 }}
                        animate={{ width: analyzed ? `${metric.score}%` : "0%" }}
                        transition={{ duration: 1, delay: 0.3 + i * 0.08, ease: "easeOut" }}
                        className="h-full rounded-full"
                        style={{
                          background: `linear-gradient(90deg, ${metric.color}80, ${metric.color})`,
                          boxShadow: `0 0 8px ${metric.color}50`,
                        }}
                      />
                    </div>
                    <div style={{ fontFamily: "JetBrains Mono, monospace", fontSize: 9, color: "#64748b", marginTop: 4 }}>
                      {metric.score < 70 ? "NEEDS IMPROVEMENT" : metric.score < 85 ? "GOOD" : "EXCELLENT"}
                    </div>
                  </motion.div>
                ))}
              </AnimatePresence>
            </div>
          </div>

          {/* AI Recommendations */}
          <AnimatePresence>
            {analyzed && selectedMetric && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: 10 }}
                className="p-5 rounded-2xl"
                style={{ background: `${selectedMetric.color}08`, border: `1px solid ${selectedMetric.color}25` }}
              >
                <div className="flex items-center gap-2 mb-3">
                  <Zap className="w-4 h-4" style={{ color: selectedMetric.color }} />
                  <span style={{ fontFamily: "JetBrains Mono, monospace", fontSize: 10, color: selectedMetric.color, letterSpacing: "0.1em" }}>
                    AI RECOMMENDATION · {selectedMetric.label.toUpperCase()}
                  </span>
                </div>
                <p style={{ fontFamily: "Outfit, sans-serif", fontSize: 14, color: "#94a3b8", lineHeight: 1.6 }}>
                  {selectedMetric.desc}. Score of <strong style={{ color: selectedMetric.color }}>{selectedMetric.score}/100</strong> indicates{" "}
                  {selectedMetric.score >= 90 ? "exceptional performance. Maintain this approach in future content." :
                   selectedMetric.score >= 80 ? "strong performance. Minor tweaks to opening hook could push this to viral territory." :
                   "moderate performance. Consider adding more concrete data points and a stronger emotional narrative arc."}
                </p>
                <div className="mt-3 grid grid-cols-2 gap-2">
                  {["Add specific numbers", "Start with tension", "Use active voice", "Include social proof"].map((tip) => (
                    <div
                      key={tip}
                      className="px-3 py-2 rounded-lg flex items-center gap-2"
                      style={{ background: "rgba(15,32,64,0.6)", border: "1px solid rgba(59,130,246,0.1)" }}
                    >
                      <div className="w-1 h-1 rounded-full flex-shrink-0" style={{ background: selectedMetric.color }} />
                      <span style={{ fontFamily: "Outfit, sans-serif", fontSize: 11, color: "#64748b" }}>{tip}</span>
                    </div>
                  ))}
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Center: DNA Helix */}
        <div
          className="relative border-x overflow-hidden"
          style={{ borderColor: "rgba(59,130,246,0.1)" }}
        >
          <div
            className="absolute inset-0"
            style={{ background: "radial-gradient(ellipse at center, rgba(139,92,246,0.05) 0%, transparent 70%)" }}
          />
          <div className="absolute top-4 left-0 right-0 text-center">
            <div style={{ fontFamily: "JetBrains Mono, monospace", fontSize: 9, color: "#64748b", letterSpacing: "0.15em" }}>
              DNA SEQUENCE VISUALIZATION
            </div>
          </div>
          <DNAHelix metrics={DNA_METRICS} />
          <div className="absolute bottom-4 left-0 right-0 text-center">
            <div style={{ fontFamily: "Outfit, sans-serif", fontSize: 28, fontWeight: 900, color: "#e2e8f0", letterSpacing: "-0.03em" }}>
              {totalScore}
            </div>
            <div style={{ fontFamily: "JetBrains Mono, monospace", fontSize: 9, color: "#64748b", letterSpacing: "0.1em" }}>VIRAL INDEX</div>
          </div>
        </div>

        {/* Right: Benchmarks */}
        <div className="overflow-y-auto p-4 space-y-4">
          <div style={{ fontFamily: "JetBrains Mono, monospace", fontSize: 10, color: "#64748b", letterSpacing: "0.1em" }}>
            VIRAL BENCHMARKS
          </div>

          {/* Overall score */}
          <div
            className="p-4 rounded-2xl text-center"
            style={{ background: "rgba(15,32,64,0.4)", border: "1px solid rgba(59,130,246,0.12)" }}
          >
            <ScoreRing score={totalScore} color="#3b82f6" size={100} />
            <div style={{ fontFamily: "Outfit, sans-serif", fontSize: 14, fontWeight: 700, color: "#e2e8f0", marginTop: 8 }}>
              Viral Potential
            </div>
            <div
              className="mt-2 px-3 py-1 rounded-full inline-block"
              style={{ background: "rgba(16,185,129,0.1)", border: "1px solid rgba(16,185,129,0.2)" }}
            >
              <span style={{ fontFamily: "JetBrains Mono, monospace", fontSize: 10, color: "#10b981" }}>HIGH PERFORMANCE</span>
            </div>
          </div>

          {/* Industry benchmarks */}
          <div
            className="p-4 rounded-2xl"
            style={{ background: "rgba(15,32,64,0.4)", border: "1px solid rgba(59,130,246,0.08)" }}
          >
            <div className="mb-3" style={{ fontFamily: "JetBrains Mono, monospace", fontSize: 9, color: "#64748b", letterSpacing: "0.08em" }}>
              INDUSTRY COMPARISON
            </div>
            <div className="space-y-3">
              {[
                { label: "Science Media", score: 71, color: "#64748b" },
                { label: "Top Performers", score: 83, color: "#3b82f6" },
                { label: "Your Content", score: totalScore, color: "#10b981" },
                { label: "Viral Threshold", score: 90, color: "#f59e0b" },
              ].map((b) => (
                <div key={b.label}>
                  <div className="flex justify-between mb-1">
                    <span style={{ fontFamily: "Outfit, sans-serif", fontSize: 11, color: "#94a3b8" }}>{b.label}</span>
                    <span style={{ fontFamily: "JetBrains Mono, monospace", fontSize: 11, color: b.color }}>{b.score}</span>
                  </div>
                  <div className="h-1 rounded-full" style={{ background: "rgba(255,255,255,0.04)" }}>
                    <motion.div
                      initial={{ width: 0 }}
                      animate={{ width: `${b.score}%` }}
                      transition={{ duration: 0.8, ease: "easeOut" }}
                      className="h-full rounded-full"
                      style={{ background: b.color }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Top science content DNA */}
          <div
            className="p-4 rounded-2xl"
            style={{ background: "rgba(15,32,64,0.4)", border: "1px solid rgba(59,130,246,0.08)" }}
          >
            <div className="mb-3" style={{ fontFamily: "JetBrains Mono, monospace", fontSize: 9, color: "#64748b", letterSpacing: "0.08em" }}>
              VIRAL CONTENT PATTERNS
            </div>
            <div className="space-y-2">
              {[
                { pattern: "Hook within 3 seconds", present: true },
                { pattern: "Concrete data point", present: true },
                { pattern: "Human story element", present: true },
                { pattern: "Call-to-action", present: false },
                { pattern: "Platform-native format", present: true },
              ].map((p) => (
                <div key={p.pattern} className="flex items-center gap-2">
                  <div
                    className="w-4 h-4 rounded-full flex items-center justify-center flex-shrink-0 text-xs"
                    style={{
                      background: p.present ? "rgba(16,185,129,0.15)" : "rgba(239,68,68,0.15)",
                      border: `1px solid ${p.present ? "rgba(16,185,129,0.3)" : "rgba(239,68,68,0.3)"}`,
                      color: p.present ? "#10b981" : "#ef4444",
                    }}
                  >
                    {p.present ? "✓" : "✕"}
                  </div>
                  <span style={{ fontFamily: "Outfit, sans-serif", fontSize: 11, color: p.present ? "#94a3b8" : "#64748b" }}>
                    {p.pattern}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Best format */}
          <div
            className="p-4 rounded-2xl"
            style={{ background: "rgba(236,72,153,0.06)", border: "1px solid rgba(236,72,153,0.15)" }}
          >
            <div className="mb-2" style={{ fontFamily: "JetBrains Mono, monospace", fontSize: 9, color: "#ec4899", letterSpacing: "0.08em" }}>
              RECOMMENDED PLATFORM
            </div>
            <div style={{ fontFamily: "Outfit, sans-serif", fontSize: 18, fontWeight: 800, color: "#e2e8f0" }}>TikTok</div>
            <div style={{ fontFamily: "JetBrains Mono, monospace", fontSize: 10, color: "#64748b", marginTop: 4 }}>
              High emotion + storytelling = short-form gold
            </div>
            <div className="mt-3 flex items-center gap-2">
              <div className="w-1.5 h-1.5 rounded-full bg-pink-400 animate-pulse" />
              <span style={{ fontFamily: "JetBrains Mono, monospace", fontSize: 9, color: "#94a3b8" }}>EST. 180K+ VIEWS</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
