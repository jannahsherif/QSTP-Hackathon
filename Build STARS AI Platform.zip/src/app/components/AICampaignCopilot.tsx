import { useState, useRef, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Bot, Send, Zap, RefreshCw, TrendingUp, Globe2, Dna, Cpu } from "lucide-react";

interface Message {
  id: string;
  role: "user" | "assistant";
  content: string;
  timestamp: Date;
  suggestions?: string[];
  metrics?: { label: string; value: string; color: string }[];
}

const INITIAL_MESSAGES: Message[] = [
  {
    id: "1",
    role: "assistant",
    content: "Hello! I'm your STARS AI Campaign Copilot — your strategic AI partner for the Stars of Science mission.\n\nI have full access to your audience data, viral DNA analysis, algorithm intelligence, and predictive flight paths. What would you like to optimize today?",
    timestamp: new Date(),
    suggestions: [
      "What should I post this week?",
      "Analyze our TikTok performance",
      "How can we reach more Gen Z scientists?",
      "Plan a viral campaign for finalist reveal",
    ],
  },
];

const AI_RESPONSES: Record<string, Message> = {
  "What should I post this week?": {
    id: "r1",
    role: "assistant",
    content: "Based on your audience DNA and current platform algorithms, here's your optimal content plan for this week:\n\n**Monday (LinkedIn + X)** — Share the finalist innovation impact report with real data. LinkedIn algorithm is favoring long-form carousel posts in your sector.\n\n**Tuesday (TikTok + Instagram)** — Behind-the-scenes of Dr. Sarah's water purification lab. Your audience engagement peaks Tue 7-9 PM GST. This content has a predicted viral score of **94/100**.\n\n**Thursday (YouTube)** — Long-form finalist feature (8-12 min). Thursday sees 40% higher watch-time completion for science content.\n\n**Friday (All platforms)** — Countdown teaser for winner announcement. Cross-platform coordination will amplify organic reach by ~3.2x.",
    timestamp: new Date(),
    metrics: [
      { label: "Predicted Total Reach", value: "680K", color: "#3b82f6" },
      { label: "Est. Engagement Rate", value: "9.3%", color: "#10b981" },
      { label: "Viral Probability", value: "78%", color: "#ec4899" },
    ],
    suggestions: [
      "Draft the TikTok script",
      "Optimize hashtags for each platform",
      "Schedule all posts for me",
    ],
  },
  "Analyze our TikTok performance": {
    id: "r2",
    role: "assistant",
    content: "Your TikTok account is your highest-performing channel — and it's accelerating. Here's the intelligence report:\n\n**Viral Score: 92/100** — You're in the top 3% of science content creators on TikTok MENA.\n\nYour strongest DNA signals are **Emotion (92)** and **Authority (95)** — this is rare for science accounts. The algorithm is actively pushing your content into non-follower feeds.\n\n**Key finding:** Your videos with a surprising data point in the first 3 seconds achieve 71% completion rate (vs. 43% platform average). Double down on this pattern.\n\n**Opportunity:** Your comment sections show 34% of viewers asking \"how can I apply?\" — add a direct Story link to increase conversion by ~280%.",
    timestamp: new Date(),
    metrics: [
      { label: "TikTok Followers", value: "450K", color: "#06b6d4" },
      { label: "Avg Video Completion", value: "71%", color: "#10b981" },
      { label: "FYP Distribution", value: "89%", color: "#8b5cf6" },
    ],
    suggestions: [
      "What hooks should I use?",
      "Compare to Instagram strategy",
      "Find trending sounds for science content",
    ],
  },
  "How can we reach more Gen Z scientists?": {
    id: "r3",
    role: "assistant",
    content: "Gen Z (18-24 year olds) make up 31% of your audience and are your fastest-growing segment, especially in South Asia (+24.8% growth) and Asia Pacific (+31.4%).\n\n**The Gen Z Algorithm:** They follow *people*, not *brands*. Your finalist scientists need to become personal brands.\n\n**Top 3 tactics with highest ROI:**\n\n1. **Finalist Takeovers** — Let each finalist run your TikTok for 24 hours. Authentic first-person science content drives 4.7x more Gen Z engagement.\n\n2. **Micro-challenges** — Create a science challenge (e.g., #InnovateWithScience). Challenges reach 91% of Gen Z vs. 67% standard posts.\n\n3. **Discord/Reddit Integration** — Gen Z scientists gather in r/science (31M members) and Discord servers. Cross-post clips with native formatting.\n\nPredicted Gen Z reach uplift with these tactics: **+156% in 90 days**.",
    timestamp: new Date(),
    metrics: [
      { label: "Current Gen Z Audience", value: "715K", color: "#8b5cf6" },
      { label: "Gen Z Growth Rate", value: "+28.4%", color: "#10b981" },
      { label: "Projected 90-day Reach", value: "1.83M", color: "#3b82f6" },
    ],
    suggestions: [
      "Draft Gen Z content brief",
      "Analyze competitor Gen Z strategy",
      "Plan finalist takeover schedule",
    ],
  },
  "Plan a viral campaign for finalist reveal": {
    id: "r4",
    role: "assistant",
    content: "A finalist reveal is your single highest-leverage moment of the season. Here's a 7-day coordinated viral campaign blueprint:\n\n**Day 1-2: Tease** — Silhouette reveals on Instagram Stories + 5-second countdown clips on TikTok. Use mystery to maximize curiosity gap score.\n\n**Day 3: Pressure Build** — LinkedIn thought leadership piece about the problems being solved. YouTube teaser trailer (2 min) optimized for recommendations.\n\n**Day 4: Countdown** — All-platform countdown. Cross-tag finalists' personal accounts. Create a custom hashtag.\n\n**Day 5: REVEAL DAY** — Staggered releases: TikTok (7 AM), Instagram Reel (12 PM), YouTube full feature (6 PM), LinkedIn article (9 AM). This creates multiple viral peaks.\n\n**Day 6-7: Amplify** — Boost top-performing content. Engage with every comment. Share UGC from scientists across the region.\n\n**Predicted campaign performance:** 2.1M reach, 8.9% engagement rate, 94 viral score.",
    timestamp: new Date(),
    metrics: [
      { label: "Predicted Campaign Reach", value: "2.1M", color: "#f59e0b" },
      { label: "Est. Viral Score", value: "94/100", color: "#ec4899" },
      { label: "Duration", value: "7 days", color: "#3b82f6" },
    ],
    suggestions: [
      "Create the teaser content brief",
      "Set up the hashtag strategy",
      "Schedule all reveal day posts",
    ],
  },
};

const QUICK_ACTIONS = [
  { icon: Zap, label: "Quick post idea", color: "#f59e0b" },
  { icon: TrendingUp, label: "Performance review", color: "#10b981" },
  { icon: Globe2, label: "Audience insights", color: "#3b82f6" },
  { icon: Dna, label: "DNA analysis", color: "#ec4899" },
];

export function AICampaignCopilot() {
  const [messages, setMessages] = useState<Message[]>(INITIAL_MESSAGES);
  const [input, setInput] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, isTyping]);

  const sendMessage = (content: string) => {
    if (!content.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      role: "user",
      content,
      timestamp: new Date(),
    };

    setMessages((prev) => [...prev, userMessage]);
    setInput("");
    setIsTyping(true);

    const delay = 1200 + Math.random() * 800;
    setTimeout(() => {
      setIsTyping(false);
      const aiResponse = AI_RESPONSES[content] || {
        id: Date.now().toString(),
        role: "assistant" as const,
        content: `Great question about "${content}". Based on your current audience data and content DNA, I'm analyzing the optimal strategy. Your MENA audience shows strong engagement patterns with science-forward content. I'd recommend focusing on authentic storytelling combined with concrete data points — this combination has shown a **94% success rate** with Stars of Science content.\n\nFor your specific question, I'd suggest cross-referencing your viral DNA scores with the platform algorithm data to find the highest-ROI opportunity. Would you like me to run a full simulation?`,
        timestamp: new Date(),
        suggestions: [
          "Run a full simulation",
          "Show me the data",
          "What are the alternatives?",
        ],
      };
      setMessages((prev) => [...prev, { ...aiResponse, id: Date.now().toString() }]);
    }, delay);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      sendMessage(input);
    }
  };

  return (
    <div className="h-full flex flex-col overflow-hidden">
      {/* Header */}
      <div className="flex items-center justify-between px-6 py-4 border-b flex-shrink-0" style={{ borderColor: "rgba(59,130,246,0.1)" }}>
        <div className="flex items-center gap-3">
          <div
            className="w-10 h-10 rounded-xl flex items-center justify-center"
            style={{
              background: "linear-gradient(135deg, #06b6d4 0%, #3b82f6 100%)",
              boxShadow: "0 0 20px rgba(6,182,212,0.3)",
            }}
          >
            <Bot className="w-5 h-5 text-white" />
          </div>
          <div>
            <div style={{ fontFamily: "JetBrains Mono, monospace", fontSize: 10, color: "#06b6d4", letterSpacing: "0.15em" }}>
              MODULE 06 · CONVERSATIONAL AI
            </div>
            <h2 style={{ fontFamily: "Outfit, sans-serif", fontSize: 22, fontWeight: 800, color: "#e2e8f0", letterSpacing: "-0.02em", lineHeight: 1.1 }}>
              AI Campaign Copilot
            </h2>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 px-3 py-1.5 rounded-full" style={{ background: "rgba(16,185,129,0.1)", border: "1px solid rgba(16,185,129,0.2)" }}>
            <div className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
            <span style={{ fontFamily: "JetBrains Mono, monospace", fontSize: 10, color: "#10b981" }}>AI ONLINE</span>
          </div>
          <button
            onClick={() => setMessages(INITIAL_MESSAGES)}
            className="p-2 rounded-xl transition-colors"
            style={{ background: "rgba(15,32,64,0.6)", color: "#64748b", border: "1px solid rgba(59,130,246,0.1)" }}
          >
            <RefreshCw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Quick actions */}
      <div className="flex gap-3 px-6 py-3 border-b flex-shrink-0 overflow-x-auto" style={{ borderColor: "rgba(59,130,246,0.1)" }}>
        {QUICK_ACTIONS.map((action) => {
          const Icon = action.icon;
          return (
            <button
              key={action.label}
              onClick={() => sendMessage(action.label)}
              className="flex items-center gap-2 px-4 py-2 rounded-xl flex-shrink-0 transition-all duration-200 hover:scale-105"
              style={{
                background: `${action.color}10`,
                border: `1px solid ${action.color}25`,
                fontFamily: "Outfit, sans-serif",
                fontSize: 12,
                fontWeight: 600,
                color: action.color,
              }}
            >
              <Icon className="w-3.5 h-3.5" />
              {action.label}
            </button>
          );
        })}
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto px-6 py-5 space-y-5">
        <AnimatePresence initial={false}>
          {messages.map((msg) => (
            <motion.div
              key={msg.id}
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.3 }}
              className={`flex gap-3 ${msg.role === "user" ? "flex-row-reverse" : ""}`}
            >
              {/* Avatar */}
              {msg.role === "assistant" ? (
                <div
                  className="w-8 h-8 rounded-xl flex items-center justify-center flex-shrink-0 mt-1"
                  style={{ background: "linear-gradient(135deg, #06b6d4, #3b82f6)", boxShadow: "0 0 12px rgba(6,182,212,0.3)" }}
                >
                  <Bot className="w-4 h-4 text-white" />
                </div>
              ) : (
                <div
                  className="w-8 h-8 rounded-xl flex items-center justify-center flex-shrink-0 mt-1"
                  style={{
                    background: "linear-gradient(135deg, #3b82f6, #8b5cf6)",
                    fontFamily: "Outfit, sans-serif",
                    fontSize: 12,
                    fontWeight: 800,
                    color: "#fff",
                  }}
                >
                  U
                </div>
              )}

              <div className={`flex flex-col gap-3 ${msg.role === "user" ? "items-end" : "items-start"} max-w-[75%]`}>
                <div
                  className="px-5 py-4 rounded-2xl"
                  style={{
                    background: msg.role === "user"
                      ? "linear-gradient(135deg, rgba(59,130,246,0.25), rgba(139,92,246,0.25))"
                      : "rgba(15, 32, 64, 0.7)",
                    border: msg.role === "user"
                      ? "1px solid rgba(59,130,246,0.3)"
                      : "1px solid rgba(59,130,246,0.1)",
                    backdropFilter: "blur(8px)",
                  }}
                >
                  <div
                    style={{
                      fontFamily: "Outfit, sans-serif",
                      fontSize: 14,
                      color: "#e2e8f0",
                      lineHeight: 1.7,
                      whiteSpace: "pre-wrap",
                    }}
                    dangerouslySetInnerHTML={{
                      __html: msg.content
                        .replace(/\*\*(.*?)\*\*/g, '<strong style="color: #e2e8f0; font-weight: 700;">$1</strong>')
                        .replace(/\n/g, "<br/>"),
                    }}
                  />
                </div>

                {/* Metrics chips */}
                {msg.metrics && (
                  <div className="flex gap-2 flex-wrap">
                    {msg.metrics.map((m) => (
                      <div
                        key={m.label}
                        className="px-3 py-2 rounded-xl"
                        style={{ background: `${m.color}10`, border: `1px solid ${m.color}25` }}
                      >
                        <div style={{ fontFamily: "JetBrains Mono, monospace", fontSize: 9, color: "#64748b" }}>{m.label}</div>
                        <div style={{ fontFamily: "Outfit, sans-serif", fontSize: 16, fontWeight: 800, color: m.color }}>{m.value}</div>
                      </div>
                    ))}
                  </div>
                )}

                {/* Suggestion chips */}
                {msg.suggestions && (
                  <div className="flex flex-wrap gap-2">
                    {msg.suggestions.map((s) => (
                      <button
                        key={s}
                        onClick={() => sendMessage(s)}
                        className="px-3 py-1.5 rounded-xl transition-all duration-200 hover:scale-105"
                        style={{
                          background: "rgba(59,130,246,0.08)",
                          border: "1px solid rgba(59,130,246,0.2)",
                          fontFamily: "Outfit, sans-serif",
                          fontSize: 12,
                          fontWeight: 500,
                          color: "#93c5fd",
                        }}
                      >
                        {s}
                      </button>
                    ))}
                  </div>
                )}

                <span style={{ fontFamily: "JetBrains Mono, monospace", fontSize: 9, color: "#475569" }}>
                  {msg.timestamp.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                </span>
              </div>
            </motion.div>
          ))}

          {isTyping && (
            <motion.div
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              className="flex gap-3"
            >
              <div
                className="w-8 h-8 rounded-xl flex items-center justify-center flex-shrink-0"
                style={{ background: "linear-gradient(135deg, #06b6d4, #3b82f6)" }}
              >
                <Bot className="w-4 h-4 text-white" />
              </div>
              <div
                className="px-5 py-4 rounded-2xl flex items-center gap-1.5"
                style={{ background: "rgba(15,32,64,0.7)", border: "1px solid rgba(59,130,246,0.1)" }}
              >
                {[0, 1, 2].map((i) => (
                  <motion.div
                    key={i}
                    className="w-2 h-2 rounded-full"
                    style={{ background: "#3b82f6" }}
                    animate={{ scale: [1, 1.3, 1], opacity: [0.5, 1, 0.5] }}
                    transition={{ repeat: Infinity, duration: 1, delay: i * 0.2 }}
                  />
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
        <div ref={bottomRef} />
      </div>

      {/* Input */}
      <div className="px-6 py-4 border-t flex-shrink-0" style={{ borderColor: "rgba(59,130,246,0.1)" }}>
        <div
          className="flex items-end gap-3 rounded-2xl px-4 py-3"
          style={{
            background: "rgba(15,32,64,0.8)",
            border: "1px solid rgba(59,130,246,0.2)",
          }}
        >
          <textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Ask anything about your campaign strategy..."
            rows={1}
            className="flex-1 bg-transparent outline-none resize-none"
            style={{
              fontFamily: "Outfit, sans-serif",
              fontSize: 14,
              color: "#e2e8f0",
              lineHeight: 1.6,
              maxHeight: 120,
            }}
          />
          <button
            onClick={() => sendMessage(input)}
            disabled={!input.trim() || isTyping}
            className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0 transition-all duration-200 hover:scale-110"
            style={{
              background: input.trim() && !isTyping
                ? "linear-gradient(135deg, #06b6d4, #3b82f6)"
                : "rgba(59,130,246,0.1)",
              opacity: !input.trim() || isTyping ? 0.5 : 1,
            }}
          >
            <Send className="w-4 h-4 text-white" />
          </button>
        </div>
        <div
          className="text-center mt-2"
          style={{ fontFamily: "JetBrains Mono, monospace", fontSize: 9, color: "#334155" }}
        >
          STARS AI COPILOT · POWERED BY ADVANCED AI · DEMO MODE
        </div>
      </div>
    </div>
  );
}
