import { useState } from "react";
import { motion } from "motion/react";
import { GlobeViewer, CLUSTERS, type Cluster } from "./GlobeViewer";
import { TrendingUp, Users, Zap, MapPin, Activity } from "lucide-react";
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer } from "recharts";

const growthData = [
  { month: "Jan", mena: 1800, europe: 900, namerica: 700, asia: 300 },
  { month: "Feb", mena: 1900, europe: 940, namerica: 730, asia: 330 },
  { month: "Mar", mena: 2050, europe: 980, namerica: 780, asia: 380 },
  { month: "Apr", mena: 2100, europe: 1020, namerica: 820, asia: 410 },
  { month: "May", mena: 2200, europe: 1060, namerica: 860, asia: 430 },
  { month: "Jun", mena: 2300, europe: 1100, namerica: 890, asia: 450 },
];

const INTERESTS = [
  { label: "Renewable Energy", pct: 34, color: "#10b981" },
  { label: "Biomedical Research", pct: 28, color: "#3b82f6" },
  { label: "AI & Robotics", pct: 21, color: "#8b5cf6" },
  { label: "Space Science", pct: 17, color: "#f59e0b" },
];

const AGE_GROUPS = [
  { range: "18-24", pct: 31, color: "#3b82f6" },
  { range: "25-34", pct: 42, color: "#8b5cf6" },
  { range: "35-44", pct: 18, color: "#06b6d4" },
  { range: "45+", pct: 9, color: "#64748b" },
];

export function AudienceDigitalTwin() {
  const [selectedCluster, setSelectedCluster] = useState<Cluster | null>(null);

  return (
    <div className="h-full flex flex-col overflow-hidden">
      {/* Header */}
      <div className="flex items-center justify-between px-6 py-4 border-b flex-shrink-0" style={{ borderColor: "rgba(59,130,246,0.1)" }}>
        <div>
          <div style={{ fontFamily: "JetBrains Mono, monospace", fontSize: 10, color: "#f59e0b", letterSpacing: "0.15em" }}>
            MODULE 01 · AUDIENCE INTELLIGENCE
          </div>
          <h2 style={{ fontFamily: "Outfit, sans-serif", fontSize: 22, fontWeight: 800, color: "#e2e8f0", letterSpacing: "-0.02em" }}>
            Audience Digital Twin
          </h2>
        </div>
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 px-3 py-1.5 rounded-full" style={{ background: "rgba(16,185,129,0.1)", border: "1px solid rgba(16,185,129,0.2)" }}>
            <div className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
            <span style={{ fontFamily: "JetBrains Mono, monospace", fontSize: 10, color: "#10b981" }}>LIVE · 6 CLUSTERS</span>
          </div>
          <div className="text-right">
            <div style={{ fontFamily: "Outfit, sans-serif", fontSize: 20, fontWeight: 800, color: "#e2e8f0" }}>5.77M</div>
            <div style={{ fontFamily: "JetBrains Mono, monospace", fontSize: 9, color: "#64748b" }}>TOTAL AUDIENCE</div>
          </div>
        </div>
      </div>

      <div className="flex-1 grid grid-cols-[1fr_320px] overflow-hidden">
        {/* Globe */}
        <div className="relative overflow-hidden">
          <div
            className="absolute inset-0"
            style={{
              background: "radial-gradient(ellipse at center, rgba(59,130,246,0.06) 0%, transparent 70%)",
            }}
          />
          <GlobeViewer onClusterSelect={setSelectedCluster} />
        </div>

        {/* Right panel */}
        <div
          className="flex flex-col overflow-y-auto border-l"
          style={{ borderColor: "rgba(59,130,246,0.1)" }}
        >
          {/* Cluster list */}
          <div className="p-4">
            <div
              className="mb-3"
              style={{ fontFamily: "JetBrains Mono, monospace", fontSize: 10, color: "#64748b", letterSpacing: "0.1em" }}
            >
              AUDIENCE CLUSTERS
            </div>
            <div className="space-y-2">
              {CLUSTERS.map((cluster, i) => (
                <motion.div
                  key={cluster.name}
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: i * 0.06 }}
                  onClick={() => setSelectedCluster(selectedCluster?.name === cluster.name ? null : cluster)}
                  className="p-3 rounded-xl cursor-pointer transition-all duration-200"
                  style={{
                    background: selectedCluster?.name === cluster.name
                      ? `rgba(${cluster.color === "#f59e0b" ? "245,158,11" : cluster.color === "#3b82f6" ? "59,130,246" : cluster.color === "#ec4899" ? "236,72,153" : cluster.color === "#8b5cf6" ? "139,92,246" : cluster.color === "#f97316" ? "249,115,22" : "16,185,129"}, 0.12)`
                      : "rgba(15, 32, 64, 0.4)",
                    border: `1px solid ${selectedCluster?.name === cluster.name ? cluster.color + "40" : "rgba(59,130,246,0.1)"}`,
                  }}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="w-2 h-2 rounded-full" style={{ background: cluster.color }} />
                      <span style={{ fontFamily: "Outfit, sans-serif", fontSize: 13, fontWeight: 600, color: "#e2e8f0" }}>
                        {cluster.name}
                      </span>
                    </div>
                    <span
                      style={{ fontFamily: "JetBrains Mono, monospace", fontSize: 10, color: "#10b981" }}
                    >
                      {cluster.growth}
                    </span>
                  </div>
                  <div className="flex items-center justify-between mt-2">
                    <span style={{ fontFamily: "JetBrains Mono, monospace", fontSize: 11, color: "#94a3b8" }}>
                      {(cluster.followers / 1e6).toFixed(2)}M followers
                    </span>
                    <span style={{ fontFamily: "JetBrains Mono, monospace", fontSize: 10, color: cluster.color }}>
                      {cluster.engagement} eng.
                    </span>
                  </div>
                  <div
                    className="mt-2 h-0.5 rounded-full"
                    style={{
                      background: `linear-gradient(90deg, ${cluster.color} ${(cluster.followers / 2300000) * 100}%, rgba(255,255,255,0.05) 0%)`,
                    }}
                  />
                </motion.div>
              ))}
            </div>
          </div>

          {/* Growth chart */}
          <div className="px-4 pb-4">
            <div className="mb-3" style={{ fontFamily: "JetBrains Mono, monospace", fontSize: 10, color: "#64748b", letterSpacing: "0.1em" }}>
              GROWTH TRAJECTORY (K)
            </div>
            <div className="h-36 rounded-xl overflow-hidden" style={{ background: "rgba(15,32,64,0.4)" }}>
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={growthData} margin={{ top: 8, right: 8, left: -30, bottom: 0 }}>
                  <defs>
                    {[["mena","#f59e0b"], ["europe","#3b82f6"], ["namerica","#10b981"], ["asia","#8b5cf6"]].map(([k, c]) => (
                      <linearGradient key={k} id={`grad-${k}`} x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor={c} stopOpacity={0.4} />
                        <stop offset="100%" stopColor={c} stopOpacity={0} />
                      </linearGradient>
                    ))}
                  </defs>
                  <XAxis dataKey="month" tick={{ fontSize: 9, fontFamily: "JetBrains Mono", fill: "#475569" }} />
                  <YAxis tick={{ fontSize: 9, fontFamily: "JetBrains Mono", fill: "#475569" }} />
                  <Tooltip
                    contentStyle={{ background: "#0a1628", border: "1px solid rgba(59,130,246,0.2)", borderRadius: 8, fontSize: 11, fontFamily: "JetBrains Mono" }}
                    labelStyle={{ color: "#e2e8f0" }}
                  />
                  <Area type="monotone" dataKey="mena" stroke="#f59e0b" fill="url(#grad-mena)" strokeWidth={1.5} />
                  <Area type="monotone" dataKey="europe" stroke="#3b82f6" fill="url(#grad-europe)" strokeWidth={1.5} />
                  <Area type="monotone" dataKey="namerica" stroke="#10b981" fill="url(#grad-namerica)" strokeWidth={1.5} />
                  <Area type="monotone" dataKey="asia" stroke="#8b5cf6" fill="url(#grad-asia)" strokeWidth={1.5} />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Interests */}
          <div className="px-4 pb-4">
            <div className="mb-3" style={{ fontFamily: "JetBrains Mono, monospace", fontSize: 10, color: "#64748b", letterSpacing: "0.1em" }}>
              INTEREST CLUSTERS
            </div>
            <div className="space-y-2.5">
              {INTERESTS.map((item) => (
                <div key={item.label}>
                  <div className="flex justify-between mb-1">
                    <span style={{ fontFamily: "Outfit, sans-serif", fontSize: 12, color: "#94a3b8" }}>{item.label}</span>
                    <span style={{ fontFamily: "JetBrains Mono, monospace", fontSize: 11, color: item.color }}>{item.pct}%</span>
                  </div>
                  <div className="h-1 rounded-full" style={{ background: "rgba(255,255,255,0.05)" }}>
                    <motion.div
                      initial={{ width: 0 }}
                      animate={{ width: `${item.pct}%` }}
                      transition={{ delay: 0.3, duration: 0.8, ease: "easeOut" }}
                      className="h-full rounded-full"
                      style={{ background: item.color }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Age groups */}
          <div className="px-4 pb-4">
            <div className="mb-3" style={{ fontFamily: "JetBrains Mono, monospace", fontSize: 10, color: "#64748b", letterSpacing: "0.1em" }}>
              AGE DEMOGRAPHICS
            </div>
            <div className="flex gap-2">
              {AGE_GROUPS.map((g) => (
                <div key={g.range} className="flex-1 text-center">
                  <div
                    className="rounded-lg mb-1.5 flex items-end justify-center"
                    style={{ height: 60, background: "rgba(15,32,64,0.4)", border: "1px solid rgba(59,130,246,0.08)" }}
                  >
                    <motion.div
                      initial={{ height: 0 }}
                      animate={{ height: `${g.pct}%` }}
                      transition={{ delay: 0.5, duration: 0.6, ease: "easeOut" }}
                      className="w-full rounded-b-lg"
                      style={{ background: `linear-gradient(180deg, ${g.color}80 0%, ${g.color}30 100%)` }}
                    />
                  </div>
                  <div style={{ fontFamily: "JetBrains Mono, monospace", fontSize: 9, color: "#64748b" }}>{g.range}</div>
                  <div style={{ fontFamily: "Outfit, sans-serif", fontSize: 12, fontWeight: 700, color: g.color }}>{g.pct}%</div>
                </div>
              ))}
            </div>
          </div>

          {/* Key signals */}
          <div className="px-4 pb-4">
            <div className="mb-3" style={{ fontFamily: "JetBrains Mono, monospace", fontSize: 10, color: "#64748b", letterSpacing: "0.1em" }}>
              AUDIENCE SIGNALS
            </div>
            <div className="grid grid-cols-2 gap-2">
              {[
                { icon: Activity, label: "Peak Hours", value: "7-9 PM GST", color: "#3b82f6" },
                { icon: Zap, label: "Best Day", value: "Tuesday", color: "#f59e0b" },
                { icon: Users, label: "Avg Session", value: "4.2 min", color: "#10b981" },
                { icon: TrendingUp, label: "Viral Index", value: "87/100", color: "#ec4899" },
              ].map((s) => {
                const Icon = s.icon;
                return (
                  <div
                    key={s.label}
                    className="p-3 rounded-xl"
                    style={{ background: "rgba(15,32,64,0.4)", border: "1px solid rgba(59,130,246,0.08)" }}
                  >
                    <Icon className="w-4 h-4 mb-1.5" style={{ color: s.color }} />
                    <div style={{ fontFamily: "JetBrains Mono, monospace", fontSize: 9, color: "#64748b" }}>{s.label}</div>
                    <div style={{ fontFamily: "Outfit, sans-serif", fontSize: 13, fontWeight: 700, color: "#e2e8f0", marginTop: 1 }}>{s.value}</div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
