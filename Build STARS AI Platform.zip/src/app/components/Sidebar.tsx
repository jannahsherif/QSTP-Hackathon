import { motion, AnimatePresence } from "motion/react";
import {
  Globe2,
  Rocket,
  Dna,
  Cpu,
  LayoutDashboard,
  Bot,
  ChevronLeft,
  ChevronRight,
  Star,
  Zap,
} from "lucide-react";

export type ModuleId = 0 | 1 | 2 | 3 | 4 | 5;

const MODULES = [
  { id: 0, icon: Globe2, label: "Audience Twin", sublabel: "Digital mapping", color: "#f59e0b" },
  { id: 1, icon: Rocket, label: "Flight Simulator", sublabel: "Predict & launch", color: "#3b82f6" },
  { id: 2, icon: Dna, label: "Viral DNA", sublabel: "Content analysis", color: "#ec4899" },
  { id: 3, icon: Cpu, label: "Algorithm Decoder", sublabel: "Platform intel", color: "#8b5cf6" },
  { id: 4, icon: LayoutDashboard, label: "Mission Control", sublabel: "Live analytics", color: "#10b981" },
  { id: 5, icon: Bot, label: "AI Copilot", sublabel: "Campaign AI", color: "#06b6d4" },
] as const;

interface Props {
  active: ModuleId;
  onChange: (id: ModuleId) => void;
  collapsed: boolean;
  onToggle: () => void;
}

export function Sidebar({ active, onChange, collapsed, onToggle }: Props) {
  return (
    <motion.div
      animate={{ width: collapsed ? 72 : 240 }}
      transition={{ type: "spring", stiffness: 300, damping: 30 }}
      className="flex flex-col h-full relative flex-shrink-0"
      style={{
        background: "rgba(4, 13, 31, 0.95)",
        borderRight: "1px solid rgba(59, 130, 246, 0.12)",
        backdropFilter: "blur(20px)",
      }}
    >
      {/* Logo */}
      <div className="flex items-center gap-3 px-4 py-5 border-b" style={{ borderColor: "rgba(59,130,246,0.1)" }}>
        <div
          className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0"
          style={{
            background: "linear-gradient(135deg, #3b82f6 0%, #8b5cf6 100%)",
            boxShadow: "0 0 20px rgba(59, 130, 246, 0.4)",
          }}
        >
          <Star className="w-5 h-5 text-white" fill="white" />
        </div>
        <AnimatePresence>
          {!collapsed && (
            <motion.div
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -10 }}
              transition={{ duration: 0.2 }}
            >
              <div style={{ fontFamily: "Outfit, sans-serif", fontWeight: 800, fontSize: 18, color: "#e2e8f0", letterSpacing: "-0.02em", lineHeight: 1 }}>
                STARS AI
              </div>
              <div style={{ fontFamily: "JetBrains Mono, monospace", fontSize: 9, color: "#3b82f6", letterSpacing: "0.15em", marginTop: 2 }}>
                MISSION CONTROL
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Status indicator */}
      <AnimatePresence>
        {!collapsed && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="mx-3 mt-3 mb-1 px-3 py-2 rounded-lg flex items-center gap-2"
            style={{ background: "rgba(16, 185, 129, 0.08)", border: "1px solid rgba(16, 185, 129, 0.2)" }}
          >
            <div className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
            <span style={{ fontFamily: "JetBrains Mono, monospace", fontSize: 10, color: "#10b981", letterSpacing: "0.05em" }}>
              SYSTEMS ONLINE
            </span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Nav modules */}
      <nav className="flex-1 px-2 py-3 space-y-1 overflow-y-auto">
        {MODULES.map((mod) => {
          const Icon = mod.icon;
          const isActive = active === mod.id;
          return (
            <motion.button
              key={mod.id}
              onClick={() => onChange(mod.id as ModuleId)}
              whileHover={{ x: 2 }}
              whileTap={{ scale: 0.97 }}
              className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl transition-all duration-200 relative group"
              style={{
                background: isActive
                  ? `rgba(${mod.color === "#f59e0b" ? "245,158,11" : mod.color === "#3b82f6" ? "59,130,246" : mod.color === "#ec4899" ? "236,72,153" : mod.color === "#8b5cf6" ? "139,92,246" : mod.color === "#10b981" ? "16,185,129" : "6,182,212"}, 0.15)`
                  : "transparent",
                border: isActive ? `1px solid ${mod.color}30` : "1px solid transparent",
              }}
            >
              {isActive && (
                <motion.div
                  layoutId="activeBar"
                  className="absolute left-0 top-1/2 -translate-y-1/2 w-0.5 h-6 rounded-full"
                  style={{ background: mod.color }}
                />
              )}
              <div
                className="w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0 transition-all duration-200"
                style={{
                  background: isActive ? `${mod.color}20` : "rgba(255,255,255,0.04)",
                  boxShadow: isActive ? `0 0 12px ${mod.color}40` : "none",
                }}
              >
                <Icon
                  className="w-4 h-4"
                  style={{ color: isActive ? mod.color : "#64748b" }}
                />
              </div>
              <AnimatePresence>
                {!collapsed && (
                  <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    className="text-left min-w-0"
                  >
                    <div
                      style={{
                        fontFamily: "Outfit, sans-serif",
                        fontSize: 13,
                        fontWeight: 600,
                        color: isActive ? "#e2e8f0" : "#94a3b8",
                        lineHeight: 1.2,
                      }}
                    >
                      {mod.label}
                    </div>
                    <div
                      style={{
                        fontFamily: "JetBrains Mono, monospace",
                        fontSize: 9,
                        color: isActive ? mod.color : "#475569",
                        letterSpacing: "0.05em",
                        marginTop: 1,
                      }}
                    >
                      {mod.sublabel.toUpperCase()}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.button>
          );
        })}
      </nav>

      {/* Bottom section */}
      <div className="p-3 border-t" style={{ borderColor: "rgba(59,130,246,0.1)" }}>
        <AnimatePresence>
          {!collapsed && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="mb-3 px-3 py-3 rounded-xl"
              style={{ background: "rgba(59, 130, 246, 0.06)", border: "1px solid rgba(59,130,246,0.12)" }}
            >
              <div className="flex items-center gap-2 mb-1">
                <Zap className="w-3.5 h-3.5" style={{ color: "#f59e0b" }} />
                <span style={{ fontFamily: "Outfit, sans-serif", fontSize: 12, fontWeight: 600, color: "#e2e8f0" }}>
                  Stars of Science
                </span>
              </div>
              <div style={{ fontFamily: "JetBrains Mono, monospace", fontSize: 9, color: "#64748b" }}>
                SEASON 15 · ACTIVE CAMPAIGN
              </div>
            </motion.div>
          )}
        </AnimatePresence>
        <button
          onClick={onToggle}
          className="w-full flex items-center justify-center p-2 rounded-lg transition-all duration-200"
          style={{
            background: "rgba(255,255,255,0.04)",
            color: "#64748b",
            border: "1px solid rgba(255,255,255,0.06)",
          }}
        >
          {collapsed ? <ChevronRight className="w-4 h-4" /> : <ChevronLeft className="w-4 h-4" />}
        </button>
      </div>
    </motion.div>
  );
}
