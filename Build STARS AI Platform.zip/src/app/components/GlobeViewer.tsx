import { useEffect, useRef, useState } from "react";
import * as THREE from "three";

interface Cluster {
  name: string;
  lat: number;
  lon: number;
  followers: number;
  growth: string;
  color: string;
  engagement: string;
}

const CLUSTERS: Cluster[] = [
  { name: "MENA Region", lat: 25, lon: 45, followers: 2300000, growth: "+18.2%", color: "#f59e0b", engagement: "8.4%" },
  { name: "Europe", lat: 52, lon: 12, followers: 1100000, growth: "+12.1%", color: "#3b82f6", engagement: "5.7%" },
  { name: "North America", lat: 40, lon: -100, followers: 890000, growth: "+9.3%", color: "#10b981", engagement: "6.2%" },
  { name: "South Asia", lat: 22, lon: 78, followers: 670000, growth: "+24.8%", color: "#ec4899", engagement: "11.3%" },
  { name: "Asia Pacific", lat: 15, lon: 108, followers: 450000, growth: "+31.4%", color: "#8b5cf6", engagement: "9.1%" },
  { name: "Africa", lat: 5, lon: 20, followers: 340000, growth: "+42.6%", color: "#f97316", engagement: "14.7%" },
];

function latLonToVec3(lat: number, lon: number, r: number) {
  const phi = (90 - lat) * (Math.PI / 180);
  const theta = (lon + 180) * (Math.PI / 180);
  return new THREE.Vector3(
    -r * Math.sin(phi) * Math.cos(theta),
    r * Math.cos(phi),
    r * Math.sin(phi) * Math.sin(theta)
  );
}

interface Props {
  compact?: boolean;
  onClusterSelect?: (cluster: Cluster | null) => void;
}

export function GlobeViewer({ compact = false, onClusterSelect }: Props) {
  const mountRef = useRef<HTMLDivElement>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const frameRef = useRef<number>(0);
  const isDraggingRef = useRef(false);
  const prevMouseRef = useRef({ x: 0, y: 0 });
  const rotationRef = useRef({ x: 0.3, y: 0 });
  const [activeCluster, setActiveCluster] = useState<Cluster | null>(null);
  const [hoveredCluster, setHoveredCluster] = useState<Cluster | null>(null);

  useEffect(() => {
    const mount = mountRef.current;
    if (!mount) return;

    const width = mount.clientWidth;
    const height = mount.clientHeight;

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 1000);
    camera.position.z = compact ? 2.8 : 2.5;

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.setClearColor(0x000000, 0);
    mount.appendChild(renderer.domElement);
    rendererRef.current = renderer;

    // Globe sphere
    const globe = new THREE.Mesh(
      new THREE.SphereGeometry(1, 64, 64),
      new THREE.MeshPhongMaterial({
        color: 0x030f1f,
        emissive: 0x0a1f3d,
        specular: 0x1e40af,
        shininess: 80,
        transparent: true,
        opacity: 0.95,
      })
    );
    scene.add(globe);

    // Wireframe overlay (lat/lon grid)
    const wireframe = new THREE.Mesh(
      new THREE.SphereGeometry(1.002, 24, 24),
      new THREE.MeshBasicMaterial({
        color: 0x1e40af,
        wireframe: true,
        transparent: true,
        opacity: 0.08,
      })
    );
    scene.add(wireframe);

    // Outer glow rings
    const glowGeom = new THREE.RingGeometry(1.05, 1.15, 64);
    const glowMat = new THREE.MeshBasicMaterial({
      color: 0x3b82f6,
      transparent: true,
      opacity: 0.06,
      side: THREE.DoubleSide,
    });
    const glow = new THREE.Mesh(glowGeom, glowMat);
    glow.rotation.x = Math.PI / 2;
    scene.add(glow);

    // Atmosphere
    const atmoGeom = new THREE.SphereGeometry(1.08, 32, 32);
    const atmoMat = new THREE.MeshBasicMaterial({
      color: 0x3b82f6,
      transparent: true,
      opacity: 0.04,
      side: THREE.BackSide,
    });
    scene.add(new THREE.Mesh(atmoGeom, atmoMat));

    // Lights
    scene.add(new THREE.AmbientLight(0x1e3a8a, 0.8));
    const sun = new THREE.DirectionalLight(0x6b9fff, 1.5);
    sun.position.set(5, 3, 5);
    scene.add(sun);
    const rim = new THREE.DirectionalLight(0x8b5cf6, 0.5);
    rim.position.set(-5, -2, -3);
    scene.add(rim);

    // Cluster markers
    const markerMeshes: THREE.Mesh[] = [];
    const clusterGroup = new THREE.Group();

    CLUSTERS.forEach((cluster) => {
      const pos = latLonToVec3(cluster.lat, cluster.lon, 1.02);
      const color = new THREE.Color(cluster.color);

      // Glow sphere
      const glowMesh = new THREE.Mesh(
        new THREE.SphereGeometry(0.035, 16, 16),
        new THREE.MeshBasicMaterial({ color, transparent: true, opacity: 0.3 })
      );
      glowMesh.position.copy(pos);
      glowMesh.userData = { cluster };
      clusterGroup.add(glowMesh);

      // Core dot
      const dot = new THREE.Mesh(
        new THREE.SphereGeometry(0.018, 16, 16),
        new THREE.MeshBasicMaterial({ color })
      );
      dot.position.copy(pos);
      dot.userData = { cluster, isCore: true };
      markerMeshes.push(dot);
      clusterGroup.add(dot);

      // Pulse ring
      const ring = new THREE.Mesh(
        new THREE.RingGeometry(0.025, 0.035, 32),
        new THREE.MeshBasicMaterial({ color, transparent: true, opacity: 0.5, side: THREE.DoubleSide })
      );
      ring.position.copy(pos);
      ring.lookAt(scene.position);
      ring.userData = { isPulse: true, baseOpacity: 0.5, phase: Math.random() * Math.PI * 2 };
      clusterGroup.add(ring);
    });

    // Connection arcs between clusters
    CLUSTERS.forEach((a, i) => {
      CLUSTERS.forEach((b, j) => {
        if (j <= i) return;
        const posA = latLonToVec3(a.lat, a.lon, 1.02);
        const posB = latLonToVec3(b.lat, b.lon, 1.02);
        const mid = posA.clone().add(posB).multiplyScalar(0.5);
        const len = posA.distanceTo(posB);
        mid.normalize().multiplyScalar(1.02 + len * 0.35);

        const curve = new THREE.QuadraticBezierCurve3(posA, mid, posB);
        const points = curve.getPoints(40);
        const geom = new THREE.BufferGeometry().setFromPoints(points);
        const mat = new THREE.LineBasicMaterial({
          color: 0x3b82f6,
          transparent: true,
          opacity: 0.12,
        });
        clusterGroup.add(new THREE.Line(geom, mat));
      });
    });

    scene.add(clusterGroup);

    // Stars background
    const starPositions: number[] = [];
    for (let i = 0; i < 2000; i++) {
      const theta = Math.random() * 2 * Math.PI;
      const phi = Math.acos(2 * Math.random() - 1);
      const r = 8 + Math.random() * 2;
      starPositions.push(
        r * Math.sin(phi) * Math.cos(theta),
        r * Math.sin(phi) * Math.sin(theta),
        r * Math.cos(phi)
      );
    }
    const starsGeom = new THREE.BufferGeometry();
    starsGeom.setAttribute("position", new THREE.Float32BufferAttribute(starPositions, 3));
    const starsMat = new THREE.PointsMaterial({ color: 0xffffff, size: 0.02, transparent: true, opacity: 0.6 });
    scene.add(new THREE.Points(starsGeom, starsMat));

    // Raycaster for click/hover
    const raycaster = new THREE.Raycaster();
    const pointer = new THREE.Vector2();

    const onPointerMove = (e: MouseEvent) => {
      const rect = mount.getBoundingClientRect();
      pointer.x = ((e.clientX - rect.left) / width) * 2 - 1;
      pointer.y = -((e.clientY - rect.top) / height) * 2 + 1;
      raycaster.setFromCamera(pointer, camera);
      const hits = raycaster.intersectObjects(markerMeshes);
      if (hits.length > 0) {
        const c = hits[0].object.userData.cluster as Cluster;
        setHoveredCluster(c);
        mount.style.cursor = "pointer";
      } else {
        setHoveredCluster(null);
        mount.style.cursor = isDraggingRef.current ? "grabbing" : "grab";
      }
    };

    const onClick = (e: MouseEvent) => {
      const rect = mount.getBoundingClientRect();
      pointer.x = ((e.clientX - rect.left) / width) * 2 - 1;
      pointer.y = -((e.clientY - rect.top) / height) * 2 + 1;
      raycaster.setFromCamera(pointer, camera);
      const hits = raycaster.intersectObjects(markerMeshes);
      if (hits.length > 0) {
        const c = hits[0].object.userData.cluster as Cluster;
        setActiveCluster((prev) => (prev?.name === c.name ? null : c));
        onClusterSelect?.(c);
      }
    };

    const onMouseDown = (e: MouseEvent) => {
      isDraggingRef.current = true;
      prevMouseRef.current = { x: e.clientX, y: e.clientY };
      mount.style.cursor = "grabbing";
    };
    const onMouseUp = () => {
      isDraggingRef.current = false;
      mount.style.cursor = "grab";
    };
    const onMouseMoveRotate = (e: MouseEvent) => {
      if (!isDraggingRef.current) return;
      const dx = e.clientX - prevMouseRef.current.x;
      const dy = e.clientY - prevMouseRef.current.y;
      rotationRef.current.y += dx * 0.005;
      rotationRef.current.x += dy * 0.003;
      rotationRef.current.x = Math.max(-Math.PI / 2, Math.min(Math.PI / 2, rotationRef.current.x));
      prevMouseRef.current = { x: e.clientX, y: e.clientY };
    };

    mount.style.cursor = "grab";
    mount.addEventListener("mousemove", onPointerMove);
    mount.addEventListener("mousemove", onMouseMoveRotate);
    mount.addEventListener("mousedown", onMouseDown);
    mount.addEventListener("mouseup", onMouseUp);
    mount.addEventListener("click", onClick);

    // Animate
    let t = 0;
    const animate = () => {
      frameRef.current = requestAnimationFrame(animate);
      t += 0.01;

      if (!isDraggingRef.current) {
        rotationRef.current.y += 0.002;
      }

      clusterGroup.rotation.y = rotationRef.current.y;
      clusterGroup.rotation.x = rotationRef.current.x;
      globe.rotation.y = rotationRef.current.y;
      globe.rotation.x = rotationRef.current.x;
      wireframe.rotation.y = rotationRef.current.y;
      wireframe.rotation.x = rotationRef.current.x;

      // Pulse rings
      clusterGroup.children.forEach((child) => {
        if (child.userData.isPulse) {
          const mesh = child as THREE.Mesh;
          const phase = mesh.userData.phase as number;
          const pulse = Math.sin(t * 2 + phase) * 0.3 + 0.7;
          const scale = 1 + Math.sin(t * 1.5 + phase) * 0.3;
          mesh.scale.setScalar(scale);
          (mesh.material as THREE.MeshBasicMaterial).opacity = pulse * 0.4;
        }
      });

      glow.rotation.z = t * 0.1;

      renderer.render(scene, camera);
    };
    animate();

    const onResize = () => {
      const w = mount.clientWidth;
      const h = mount.clientHeight;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };
    window.addEventListener("resize", onResize);

    return () => {
      cancelAnimationFrame(frameRef.current);
      window.removeEventListener("resize", onResize);
      mount.removeEventListener("mousemove", onPointerMove);
      mount.removeEventListener("mousemove", onMouseMoveRotate);
      mount.removeEventListener("mousedown", onMouseDown);
      mount.removeEventListener("mouseup", onMouseUp);
      mount.removeEventListener("click", onClick);
      renderer.dispose();
      if (mount.contains(renderer.domElement)) mount.removeChild(renderer.domElement);
    };
  }, [compact, onClusterSelect]);

  return (
    <div className="relative w-full h-full">
      <div ref={mountRef} className="w-full h-full" />
      {(hoveredCluster || activeCluster) && (
        <div
          className="absolute bottom-4 left-1/2 -translate-x-1/2 px-4 py-3 rounded-xl text-sm"
          style={{
            background: "rgba(10, 22, 40, 0.9)",
            border: "1px solid rgba(59, 130, 246, 0.4)",
            backdropFilter: "blur(12px)",
            minWidth: 220,
          }}
        >
          {(() => {
            const c = activeCluster || hoveredCluster!;
            return (
              <div>
                <div className="flex items-center gap-2 mb-2">
                  <div className="w-2.5 h-2.5 rounded-full" style={{ background: c.color }} />
                  <span style={{ fontFamily: "Outfit, sans-serif", fontWeight: 600, color: "#e2e8f0" }}>{c.name}</span>
                </div>
                <div className="grid grid-cols-3 gap-3">
                  <div>
                    <div style={{ fontFamily: "JetBrains Mono, monospace", fontSize: 11, color: "#64748b" }}>FOLLOWERS</div>
                    <div style={{ fontFamily: "JetBrains Mono, monospace", fontSize: 13, color: "#e2e8f0", fontWeight: 600 }}>
                      {(c.followers / 1e6).toFixed(1)}M
                    </div>
                  </div>
                  <div>
                    <div style={{ fontFamily: "JetBrains Mono, monospace", fontSize: 11, color: "#64748b" }}>GROWTH</div>
                    <div style={{ fontFamily: "JetBrains Mono, monospace", fontSize: 13, color: "#10b981", fontWeight: 600 }}>
                      {c.growth}
                    </div>
                  </div>
                  <div>
                    <div style={{ fontFamily: "JetBrains Mono, monospace", fontSize: 11, color: "#64748b" }}>ENGAGE</div>
                    <div style={{ fontFamily: "JetBrains Mono, monospace", fontSize: 13, color: c.color, fontWeight: 600 }}>
                      {c.engagement}
                    </div>
                  </div>
                </div>
              </div>
            );
          })()}
        </div>
      )}
    </div>
  );
}

export { CLUSTERS };
export type { Cluster };
