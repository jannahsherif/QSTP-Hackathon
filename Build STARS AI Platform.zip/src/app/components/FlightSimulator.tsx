import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Rocket, TrendingUp, Eye, Heart, Share2, MessageCircle, Play, RotateCcw, Zap, Clock, Target } from "lucide-react";
import { RadarChart, Radar, PolarGrid, PolarAngleAxis, ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, Cell } from "recharts";

const PLATFORMS = [
  {
    id: "instagram",
    name: "Instagram",
    color: "#ec4899",
    emoji: "📸",
    metrics: { reach: 45200, likes: 12300, comments: 890, shares: 1240, saves: 3400, impressions: 67000 },
    score: 84,
    bestTime: "7:30 PM GST",
    format: "Reel (60s)",
    confidence: 91,
  },
  {
    id: "tiktok",
    name: "TikTok",
    color: "#06b6d4",
    emoji: "🎵",
    metrics: { reach: 182000, likes: 23400, comments: 4200, shares: 8900, saves: 0, impressions: 240000 },
    score: 92,
    bestTime: "8:00 PM GST",
    format: "Short Video (15-30s)",
    confidence: 87,
  },
  {
    id: "linkedin",
    name: "LinkedIn",
    color: "#3b82f6",
    emoji: "💼",
    metrics: { reach: 28000, likes: 3200, comments: 560, shares: 890, saves: 0, impressions: 41000 },
    score: 76,
    bestTime: "9:00 AM GST",
    format: "Article + Video",
    confidence: 83,
  },
  {
    id: "youtube",
    name: "YouTube",
    color: "#ef4444",
    emoji: "▶️",
    metrics: { reach: 95000, likes: 8700, comments: 1240, shares: 0, saves: 0, impressions: 120000 },
    score: 88,
    bestTime: "6:00 PM GST",
    format: "Long-form (8-12 min)",
    confidence: 89,
  },
  {
    id: "x",
    name: "X (Twitter)",
    color: "#e2e8f0",
    emoji: "✕",
    metrics: { reach: 67000, likes: 4500, comments: 1890, shares: 3400, saves: 0, impressions: 89000 },
    score: 79,
    bestTime: "12:00 PM GST",
    format: "Thread + Clip",
    confidence: 78,
  },
];

const CONTENT_TYPES = [
  "Behind-the-scenes lab tour",
  "Finalist invention reveal",
  "Expert panel discussion",
  "Innovation challenge recap",
  "Science fact of the week",
];

function AnimatedCounter({ value, prefix = "", suffix = "" }: { value: number; prefix?: string; suffix?: string }) {
  const [display, setDisplay] = useState(0);
  useEffect(() => {
    let start = 0;
    const step = value / 40;
    const interval = setInterval(() => {
      start += step;
      if (start >= value) {
        setDisplay(value);
        clearInterval(interval);
      } else {
        setDisplay(Math.floor(start));
      }
    }, 20);
    return () => clearInterval(interval);
  }, [value]);

  const fmt = (n: number) => n >= 1000 ? (n / 1000).toFixed(1) + "K" : n.toString();
  return <span>{prefix}{fmt(display)}{suffix}</span>;
}

export function FlightSimulator() {
  const [selectedPlatform, setSelectedPlatform] = useState(PLATFORMS[0]);
  const [contentType, setContentType] = useState(CONTENT_TYPES[0]);
  const [simulating, setSimulating] = useState(false);
  const [simDone, setSimDone] = useState(false);
  const [simProgress, setSimProgress] = useState(0);

  const runSimulation = () => {
    setSimulating(true);
    setSimDone(false);
    setSimProgress(0);
    let p = 0;
    const iv = setInterval(() => {
      p += 3 + Math.random() * 5;
      setSimProgress(Math.min(p, 100));
      if (p >= 100) {
        clearInterval(iv);
        setSimulating(false);
        setSimDone(true);
      }
    }, 60);
  };

  const radarData = PLATFORMS.map((p) => ({ platform: p.name.split(" ")[0], score: p.score }));

  return (
    <div className="h-full flex flex-col overflow-hidden">
      {/* Header */}
      <div className="flex items-center justify-between px-6 py-4 border-b flex-shrink-0" style={{ borderColor: "rgba(59,130,246,0.1)" }}>
        <div>
          <div style={{ fontFamily: "JetBrains Mono, monospace", fontSize: 10, color: "#3b82f6", letterSpacing: "0.15em" }}>
            MODULE 02 · PREDICTIVE ENGINE
          </div>
          <h2 style={{ fontFamily: "Outfit, sans-serif", fontSize: 22, fontWeight: 800, color: "#e2e8f0", letterSpacing: "-0.02em" }}>
            Social Media Flight Simulator
          </h2>
        </div>
        <div className="flex items-center gap-3">
          <select
            value={contentType}
            onChange={(e) => setContentType(e.target.value)}
            className="px-3 py-2 rounded-xl text-sm outline-none"
            style={{
              background: "rgba(15,32,64,0.8)",
              border: "1px solid rgba(59,130,246,0.2)",
              color: "#94a3b8",
              fontFamily: "Outfit, sans-serif",
              fontSize: 13,
            }}
          >
            {CONTENT_TYPES.map((t) => <option key={t} value={t}>{t}</option>)}
          </select>
          <button
            onClick={runSimulation}
            disabled={simulating}
            className="flex items-center gap-2 px-5 py-2.5 rounded-xl transition-all duration-200 hover:scale-105"
            style={{
              background: simulating ? "rgba(59,130,246,0.2)" : "linear-gradient(135deg, #3b82f6 0%, #8b5cf6 100%)",
              boxShadow: simulating ? "none" : "0 0 20px rgba(59,130,246,0.3)",
              fontFamily: "Outfit, sans-serif",
              fontSize: 14,
              fontWeight: 700,
              color: "#fff",
            }}
          >
            {simulating ? (
              <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
            ) : (
              <Rocket className="w-4 h-4" />
            )}
            {simulating ? "Simulating..." : "Run Simulation"}
          </button>
        </div>
      </div>

      {/* Simulation progress */}
      <AnimatePresence>
        {(simulating || simDone) && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="px-6 py-3 border-b overflow-hidden"
            style={{ borderColor: "rgba(59,130,246,0.1)" }}
          >
            <div className="flex items-center gap-4">
              <div className="flex-1">
                <div className="flex justify-between mb-1.5">
                  <span style={{ fontFamily: "JetBrains Mono, monospace", fontSize: 10, color: "#64748b" }}>
                    {simulating ? "CALCULATING FLIGHT TRAJECTORY..." : "SIMULATION COMPLETE"}
                  </span>
                  <span style={{ fontFamily: "JetBrains Mono, monospace", fontSize: 10, color: "#3b82f6" }}>
                    {Math.round(simProgress)}%
                  </span>
                </div>
                <div className="h-1 rounded-full" style={{ background: "rgba(59,130,246,0.1)" }}>
                  <motion.div
                    className="h-full rounded-full"
                    style={{
                      width: `${simProgress}%`,
                      background: "linear-gradient(90deg, #3b82f6 0%, #8b5cf6 100%)",
                      boxShadow: "0 0 8px rgba(59,130,246,0.5)",
                    }}
                  />
                </div>
              </div>
              {simDone && (
                <div className="flex items-center gap-1.5">
                  <div className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                  <span style={{ fontFamily: "JetBrains Mono, monospace", fontSize: 10, color: "#10b981" }}>READY FOR LAUNCH</span>
                </div>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="flex-1 grid grid-cols-[280px_1fr] overflow-hidden">
        {/* Platform selector */}
        <div
          className="flex flex-col overflow-y-auto border-r p-4 gap-2"
          style={{ borderColor: "rgba(59,130,246,0.1)" }}
        >
          <div className="mb-2" style={{ fontFamily: "JetBrains Mono, monospace", fontSize: 10, color: "#64748b", letterSpacing: "0.1em" }}>
            SELECT PLATFORM
          </div>
          {PLATFORMS.map((platform) => (
            <motion.button
              key={platform.id}
              onClick={() => setSelectedPlatform(platform)}
              whileHover={{ x: 2 }}
              className="p-4 rounded-2xl text-left transition-all duration-200"
              style={{
                background: selectedPlatform.id === platform.id
                  ? `${platform.color}15`
                  : "rgba(15,32,64,0.4)",
                border: `1px solid ${selectedPlatform.id === platform.id ? platform.color + "40" : "rgba(59,130,246,0.08)"}`,
              }}
            >
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <span style={{ fontSize: 18 }}>{platform.emoji}</span>
                  <span style={{ fontFamily: "Outfit, sans-serif", fontSize: 14, fontWeight: 700, color: "#e2e8f0" }}>
                    {platform.name}
                  </span>
                </div>
                <div
                  className="w-9 h-9 rounded-full flex items-center justify-center text-sm font-black"
                  style={{
                    background: `${platform.color}20`,
                    border: `2px solid ${platform.color}40`,
                    color: platform.color,
                    fontFamily: "Outfit, sans-serif",
                  }}
                >
                  {platform.score}
                </div>
              </div>
              <div className="space-y-1.5">
                <div className="flex justify-between">
                  <span style={{ fontFamily: "JetBrains Mono, monospace", fontSize: 9, color: "#64748b" }}>REACH</span>
                  <span style={{ fontFamily: "JetBrains Mono, monospace", fontSize: 10, color: "#94a3b8" }}>
                    {platform.metrics.reach >= 1000 ? (platform.metrics.reach / 1000).toFixed(0) + "K" : platform.metrics.reach}
                  </span>
                </div>
                <div className="h-0.5 rounded-full" style={{ background: "rgba(255,255,255,0.05)" }}>
                  <div
                    className="h-full rounded-full"
                    style={{ width: `${platform.score}%`, background: platform.color }}
                  />
                </div>
                <div style={{ fontFamily: "JetBrains Mono, monospace", fontSize: 9, color: "#475569" }}>
                  {platform.confidence}% confidence
                </div>
              </div>
            </motion.button>
          ))}

          {/* Radar chart */}
          <div className="mt-4">
            <div className="mb-2" style={{ fontFamily: "JetBrains Mono, monospace", fontSize: 10, color: "#64748b", letterSpacing: "0.1em" }}>
              PLATFORM COMPARISON
            </div>
            <div className="h-44" style={{ background: "rgba(15,32,64,0.3)", borderRadius: 12 }}>
              <ResponsiveContainer width="100%" height="100%">
                <RadarChart data={radarData}>
                  <PolarGrid stroke="rgba(59,130,246,0.1)" />
                  <PolarAngleAxis dataKey="platform" tick={{ fontSize: 9, fontFamily: "JetBrains Mono", fill: "#64748b" }} />
                  <Radar dataKey="score" stroke="#3b82f6" fill="#3b82f6" fillOpacity={0.15} strokeWidth={1.5} />
                </RadarChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>

        {/* Main prediction view */}
        <div className="overflow-y-auto p-6 space-y-5">
          {/* Platform header */}
          <div
            className="p-5 rounded-2xl"
            style={{
              background: `${selectedPlatform.color}08`,
              border: `1px solid ${selectedPlatform.color}25`,
            }}
          >
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-3">
                <span style={{ fontSize: 28 }}>{selectedPlatform.emoji}</span>
                <div>
                  <h3 style={{ fontFamily: "Outfit, sans-serif", fontSize: 20, fontWeight: 800, color: "#e2e8f0" }}>
                    {selectedPlatform.name}
                  </h3>
                  <div style={{ fontFamily: "JetBrains Mono, monospace", fontSize: 10, color: "#64748b" }}>
                    {selectedPlatform.format} · {selectedPlatform.bestTime}
                  </div>
                </div>
              </div>
              <div className="text-right">
                <div
                  style={{
                    fontFamily: "Outfit, sans-serif",
                    fontSize: 48,
                    fontWeight: 900,
                    color: selectedPlatform.color,
                    lineHeight: 1,
                    letterSpacing: "-0.03em",
                  }}
                >
                  {selectedPlatform.score}
                </div>
                <div style={{ fontFamily: "JetBrains Mono, monospace", fontSize: 10, color: "#64748b" }}>
                  FLIGHT SCORE
                </div>
              </div>
            </div>

            {/* Score bar */}
            <div>
              <div className="h-2 rounded-full mb-1" style={{ background: "rgba(255,255,255,0.05)" }}>
                <motion.div
                  initial={{ width: 0 }}
                  animate={{ width: `${selectedPlatform.score}%` }}
                  transition={{ duration: 1, ease: "easeOut" }}
                  className="h-full rounded-full"
                  style={{
                    background: `linear-gradient(90deg, ${selectedPlatform.color}80, ${selectedPlatform.color})`,
                    boxShadow: `0 0 12px ${selectedPlatform.color}60`,
                  }}
                />
              </div>
              <div className="flex justify-between">
                <span style={{ fontFamily: "JetBrains Mono, monospace", fontSize: 9, color: "#475569" }}>LOW PERFORMANCE</span>
                <span style={{ fontFamily: "JetBrains Mono, monospace", fontSize: 9, color: "#475569" }}>HIGH PERFORMANCE</span>
              </div>
            </div>
          </div>

          {/* Metrics grid */}
          <div>
            <div className="mb-3" style={{ fontFamily: "JetBrains Mono, monospace", fontSize: 10, color: "#64748b", letterSpacing: "0.1em" }}>
              PREDICTED PERFORMANCE
            </div>
            <div className="grid grid-cols-3 gap-3">
              {[
                { icon: Eye, label: "Predicted Reach", value: selectedPlatform.metrics.reach, color: "#3b82f6" },
                { icon: Heart, label: "Predicted Likes", value: selectedPlatform.metrics.likes, color: "#ec4899" },
                { icon: MessageCircle, label: "Comments", value: selectedPlatform.metrics.comments, color: "#8b5cf6" },
                { icon: Share2, label: "Shares", value: selectedPlatform.metrics.shares || selectedPlatform.metrics.impressions, color: "#10b981" },
                { icon: TrendingUp, label: "Impressions", value: selectedPlatform.metrics.impressions, color: "#f59e0b" },
                { icon: Target, label: "Confidence", value: `${selectedPlatform.confidence}%` as unknown as number, color: "#06b6d4" },
              ].map((m) => {
                const Icon = m.icon;
                return (
                  <motion.div
                    key={m.label}
                    whileHover={{ y: -2 }}
                    className="p-4 rounded-2xl"
                    style={{ background: "rgba(15,32,64,0.6)", border: "1px solid rgba(59,130,246,0.08)" }}
                  >
                    <Icon className="w-5 h-5 mb-2" style={{ color: m.color }} />
                    <div style={{ fontFamily: "JetBrains Mono, monospace", fontSize: 9, color: "#64748b", letterSpacing: "0.05em" }}>
                      {m.label.toUpperCase()}
                    </div>
                    <div
                      style={{
                        fontFamily: "Outfit, sans-serif",
                        fontSize: 22,
                        fontWeight: 800,
                        color: m.color,
                        letterSpacing: "-0.02em",
                        marginTop: 2,
                      }}
                    >
                      {typeof m.value === "string" ? m.value : (
                        simDone ? <AnimatedCounter value={m.value} /> : (
                          m.value >= 1000 ? (m.value / 1000).toFixed(1) + "K" : m.value
                        )
                      )}
                    </div>
                  </motion.div>
                );
              })}
            </div>
          </div>

          {/* Timing recommendations */}
          <div>
            <div className="mb-3" style={{ fontFamily: "JetBrains Mono, monospace", fontSize: 10, color: "#64748b", letterSpacing: "0.1em" }}>
              OPTIMAL LAUNCH WINDOW
            </div>
            <div className="grid grid-cols-3 gap-3">
              {[
                { label: "Best Time", value: selectedPlatform.bestTime, icon: Clock, color: "#3b82f6" },
                { label: "Content Format", value: selectedPlatform.format, icon: Play, color: "#8b5cf6" },
                { label: "Boost Potential", value: "+34% with hashtags", icon: Zap, color: "#f59e0b" },
              ].map((item) => {
                const Icon = item.icon;
                return (
                  <div
                    key={item.label}
                    className="p-4 rounded-2xl flex items-center gap-3"
                    style={{ background: "rgba(15,32,64,0.4)", border: "1px solid rgba(59,130,246,0.08)" }}
                  >
                    <div
                      className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0"
                      style={{ background: `${item.color}15` }}
                    >
                      <Icon className="w-4 h-4" style={{ color: item.color }} />
                    </div>
                    <div>
                      <div style={{ fontFamily: "JetBrains Mono, monospace", fontSize: 9, color: "#64748b" }}>{item.label.toUpperCase()}</div>
                      <div style={{ fontFamily: "Outfit, sans-serif", fontSize: 13, fontWeight: 600, color: "#e2e8f0", marginTop: 1 }}>
                        {item.value}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* All platforms bar chart */}
          <div>
            <div className="mb-3" style={{ fontFamily: "JetBrains Mono, monospace", fontSize: 10, color: "#64748b", letterSpacing: "0.1em" }}>
              REACH COMPARISON (ALL PLATFORMS)
            </div>
            <div
              className="h-48 rounded-2xl overflow-hidden"
              style={{ background: "rgba(15,32,64,0.4)", border: "1px solid rgba(59,130,246,0.08)" }}
            >
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={PLATFORMS.map((p) => ({ name: p.name.split(" ")[0], reach: Math.round(p.metrics.reach / 1000), color: p.color }))} margin={{ top: 12, right: 12, left: -20, bottom: 0 }}>
                  <XAxis dataKey="name" tick={{ fontSize: 10, fontFamily: "JetBrains Mono", fill: "#64748b" }} />
                  <YAxis tick={{ fontSize: 9, fontFamily: "JetBrains Mono", fill: "#475569" }} unit="K" />
                  <Tooltip
                    contentStyle={{ background: "#0a1628", border: "1px solid rgba(59,130,246,0.2)", borderRadius: 8, fontSize: 11, fontFamily: "JetBrains Mono" }}
                    formatter={(v: number) => [`${v}K`, "Reach"]}
                  />
                  <Bar dataKey="reach" radius={[6, 6, 0, 0]}>
                    {PLATFORMS.map((p) => (
                      <Cell key={p.id} fill={p.color} opacity={p.id === selectedPlatform.id ? 1 : 0.4} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
