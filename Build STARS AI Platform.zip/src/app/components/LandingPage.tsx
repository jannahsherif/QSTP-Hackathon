import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { ParticleField } from "./ParticleField";
import { GlobeViewer } from "./GlobeViewer";
import {
  Globe2, Rocket, Dna, Cpu, LayoutDashboard, Bot,
  ArrowRight, Star, ChevronRight, Zap, Shield, TrendingUp,
} from "lucide-react";

const MODULES = [
  { icon: Globe2, label: "Audience Digital Twin", desc: "Interactive 3D globe with live audience clusters across 180+ countries", color: "#f59e0b" },
  { icon: Rocket, label: "Flight Simulator", desc: "Predict performance on Instagram, TikTok, LinkedIn, YouTube & X before publishing", color: "#3b82f6" },
  { icon: Dna, label: "Viral DNA Analyzer", desc: "Score content on Innovation, Emotion, Curiosity Gap, Authority & Shareability", color: "#ec4899" },
  { icon: Cpu, label: "Algorithm Decoder", desc: "Understand how each platform algorithm will react to your content", color: "#8b5cf6" },
  { icon: LayoutDashboard, label: "Mission Control", desc: "Real-time analytics command center with live performance data", color: "#10b981" },
  { icon: Bot, label: "AI Campaign Copilot", desc: "Conversational AI assistant for strategic campaign planning", color: "#06b6d4" },
];

const STATS = [
  { value: "2.3M+", label: "Audience Reach" },
  { value: "98.2%", label: "Prediction Accuracy" },
  { value: "6", label: "AI Modules" },
  { value: "5", label: "Platforms Decoded" },
];

interface Props {
  onEnter: () => void;
}

export function LandingPage({ onEnter }: Props) {
  const [step, setStep] = useState<"hero" | "onboarding">("hero");
  const [onboardStep, setOnboardStep] = useState(0);
  const [orgName, setOrgName] = useState("Stars of Science");
  const [loading, setLoading] = useState(false);

  const handleLaunch = () => {
    if (step === "hero") {
      setStep("onboarding");
    } else {
      setLoading(true);
      setTimeout(() => {
        setLoading(false);
        onEnter();
      }, 2000);
    }
  };

  const onboardSteps = [
    {
      title: "Welcome to STARS AI",
      subtitle: "Your AI social media co-pilot for Stars of Science",
      content: (
        <div className="space-y-4">
          <div>
            <label style={{ fontFamily: "JetBrains Mono, monospace", fontSize: 11, color: "#64748b", letterSpacing: "0.1em" }}>
              ORGANIZATION NAME
            </label>
            <input
              value={orgName}
              onChange={(e) => setOrgName(e.target.value)}
              className="w-full mt-1.5 px-4 py-3 rounded-xl outline-none transition-all"
              style={{
                background: "rgba(15, 32, 64, 0.8)",
                border: "1px solid rgba(59, 130, 246, 0.3)",
                color: "#e2e8f0",
                fontFamily: "Outfit, sans-serif",
              }}
              placeholder="Stars of Science"
            />
          </div>
          <div>
            <label style={{ fontFamily: "JetBrains Mono, monospace", fontSize: 11, color: "#64748b", letterSpacing: "0.1em" }}>
              MISSION TYPE
            </label>
            <div className="grid grid-cols-2 gap-3 mt-1.5">
              {["Science Communication", "Innovation Showcase", "Education Campaign", "Brand Awareness"].map((t) => (
                <button
                  key={t}
                  className="px-3 py-2.5 rounded-xl text-left transition-all"
                  style={{
                    background: t === "Science Communication" ? "rgba(59, 130, 246, 0.2)" : "rgba(15, 32, 64, 0.6)",
                    border: t === "Science Communication" ? "1px solid rgba(59, 130, 246, 0.5)" : "1px solid rgba(59, 130, 246, 0.1)",
                    color: t === "Science Communication" ? "#93c5fd" : "#64748b",
                    fontFamily: "Outfit, sans-serif",
                    fontSize: 13,
                  }}
                >
                  {t}
                </button>
              ))}
            </div>
          </div>
        </div>
      ),
    },
    {
      title: "Connect Your Platforms",
      subtitle: "Link your social media accounts for real-time data",
      content: (
        <div className="space-y-3">
          {[
            { name: "Instagram", handle: "@starsofscience", color: "#ec4899", connected: true },
            { name: "TikTok", handle: "@starsofscience_tv", color: "#06b6d4", connected: true },
            { name: "LinkedIn", handle: "Stars of Science", color: "#3b82f6", connected: false },
            { name: "YouTube", handle: "Stars of Science", color: "#ef4444", connected: true },
            { name: "X (Twitter)", handle: "@Stars_Science", color: "#e2e8f0", connected: false },
          ].map((p) => (
            <div
              key={p.name}
              className="flex items-center justify-between px-4 py-3 rounded-xl"
              style={{
                background: p.connected ? "rgba(16, 185, 129, 0.06)" : "rgba(15, 32, 64, 0.6)",
                border: p.connected ? "1px solid rgba(16, 185, 129, 0.2)" : "1px solid rgba(59, 130, 246, 0.1)",
              }}
            >
              <div className="flex items-center gap-3">
                <div className="w-2 h-2 rounded-full" style={{ background: p.color }} />
                <div>
                  <div style={{ fontFamily: "Outfit, sans-serif", fontSize: 14, fontWeight: 600, color: "#e2e8f0" }}>{p.name}</div>
                  <div style={{ fontFamily: "JetBrains Mono, monospace", fontSize: 10, color: "#64748b" }}>{p.handle}</div>
                </div>
              </div>
              <div
                className="px-3 py-1 rounded-lg text-xs font-medium"
                style={{
                  background: p.connected ? "rgba(16, 185, 129, 0.15)" : "rgba(59, 130, 246, 0.1)",
                  color: p.connected ? "#10b981" : "#3b82f6",
                  fontFamily: "JetBrains Mono, monospace",
                  fontSize: 10,
                  letterSpacing: "0.05em",
                }}
              >
                {p.connected ? "LINKED" : "CONNECT"}
              </div>
            </div>
          ))}
        </div>
      ),
    },
    {
      title: "Mission Briefing Complete",
      subtitle: "STARS AI is ready to launch your campaign to orbit",
      content: (
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-3">
            {[
              { icon: Globe2, label: "Audience clusters mapped", value: "6 regions", color: "#f59e0b" },
              { icon: Rocket, label: "Flight paths calculated", value: "5 platforms", color: "#3b82f6" },
              { icon: Dna, label: "DNA baseline set", value: "Ready", color: "#ec4899" },
              { icon: Shield, label: "Algorithm models loaded", value: "97.3% accuracy", color: "#10b981" },
            ].map((item) => {
              const Icon = item.icon;
              return (
                <div
                  key={item.label}
                  className="p-4 rounded-xl"
                  style={{ background: "rgba(15, 32, 64, 0.6)", border: "1px solid rgba(59, 130, 246, 0.1)" }}
                >
                  <Icon className="w-5 h-5 mb-2" style={{ color: item.color }} />
                  <div style={{ fontFamily: "JetBrains Mono, monospace", fontSize: 11, color: "#64748b" }}>{item.label}</div>
                  <div style={{ fontFamily: "Outfit, sans-serif", fontSize: 14, fontWeight: 600, color: item.color, marginTop: 2 }}>{item.value}</div>
                </div>
              );
            })}
          </div>
          <div
            className="p-4 rounded-xl flex items-center gap-3"
            style={{ background: "rgba(59, 130, 246, 0.08)", border: "1px solid rgba(59, 130, 246, 0.2)" }}
          >
            <div className="w-2 h-2 rounded-full bg-blue-400 animate-pulse" />
            <span style={{ fontFamily: "JetBrains Mono, monospace", fontSize: 11, color: "#93c5fd" }}>
              All systems nominal · {orgName} campaign loaded
            </span>
          </div>
        </div>
      ),
    },
  ];

  return (
    <div className="relative w-full h-full overflow-hidden" style={{ background: "#020817" }}>
      <ParticleField count={100} />

      {/* Radial glow */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          background: "radial-gradient(ellipse 80% 60% at 50% 40%, rgba(59,130,246,0.08) 0%, transparent 70%)",
        }}
      />
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          background: "radial-gradient(ellipse 60% 40% at 80% 60%, rgba(139,92,246,0.06) 0%, transparent 60%)",
        }}
      />

      <AnimatePresence mode="wait">
        {step === "hero" && (
          <motion.div
            key="hero"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0, y: -20 }}
            className="relative z-10 w-full h-full flex flex-col"
          >
            {/* Nav */}
            <nav className="flex items-center justify-between px-8 py-5">
              <div className="flex items-center gap-3">
                <div
                  className="w-9 h-9 rounded-xl flex items-center justify-center"
                  style={{
                    background: "linear-gradient(135deg, #3b82f6 0%, #8b5cf6 100%)",
                    boxShadow: "0 0 24px rgba(59, 130, 246, 0.5)",
                  }}
                >
                  <Star className="w-5 h-5 text-white" fill="white" />
                </div>
                <div>
                  <div style={{ fontFamily: "Outfit, sans-serif", fontWeight: 800, fontSize: 18, color: "#e2e8f0", letterSpacing: "-0.02em" }}>
                    STARS AI
                  </div>
                  <div style={{ fontFamily: "JetBrains Mono, monospace", fontSize: 8, color: "#3b82f6", letterSpacing: "0.2em" }}>
                    MISSION CONTROL
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-6">
                {["Platform", "Features", "Science", "Pricing"].map((item) => (
                  <span
                    key={item}
                    className="cursor-pointer transition-colors duration-200 hover:text-blue-400"
                    style={{ fontFamily: "Outfit, sans-serif", fontSize: 14, fontWeight: 500, color: "#64748b" }}
                  >
                    {item}
                  </span>
                ))}
                <button
                  onClick={handleLaunch}
                  className="flex items-center gap-2 px-5 py-2.5 rounded-xl transition-all duration-200 hover:scale-105"
                  style={{
                    background: "linear-gradient(135deg, #3b82f6 0%, #8b5cf6 100%)",
                    boxShadow: "0 0 20px rgba(59, 130, 246, 0.35)",
                    fontFamily: "Outfit, sans-serif",
                    fontSize: 14,
                    fontWeight: 600,
                    color: "#fff",
                  }}
                >
                  Launch Mission
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </nav>

            {/* Hero */}
            <div className="flex flex-1 items-center px-8 gap-16 overflow-hidden">
              {/* Left content */}
              <div className="flex-1 max-w-xl">
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.2 }}
                  className="mb-5"
                >
                  <div
                    className="inline-flex items-center gap-2 px-4 py-2 rounded-full mb-6"
                    style={{
                      background: "rgba(59, 130, 246, 0.1)",
                      border: "1px solid rgba(59, 130, 246, 0.25)",
                    }}
                  >
                    <div className="w-1.5 h-1.5 rounded-full bg-blue-400 animate-pulse" />
                    <span style={{ fontFamily: "JetBrains Mono, monospace", fontSize: 11, color: "#93c5fd", letterSpacing: "0.08em" }}>
                      AI MISSION CONTROL · SEASON 15
                    </span>
                  </div>

                  <h1
                    style={{
                      fontFamily: "Outfit, sans-serif",
                      fontSize: "clamp(42px, 5vw, 68px)",
                      fontWeight: 900,
                      lineHeight: 1.05,
                      letterSpacing: "-0.03em",
                      color: "#e2e8f0",
                    }}
                  >
                    Launch Your{" "}
                    <span
                      style={{
                        background: "linear-gradient(135deg, #3b82f6 0%, #8b5cf6 50%, #06b6d4 100%)",
                        WebkitBackgroundClip: "text",
                        WebkitTextFillColor: "transparent",
                        backgroundClip: "text",
                      }}
                    >
                      Science
                    </span>
                    <br />
                    Into Orbit
                  </h1>

                  <p
                    className="mt-5 leading-relaxed"
                    style={{ fontFamily: "Outfit, sans-serif", fontSize: 17, color: "#64748b", maxWidth: 460 }}
                  >
                    The world's first AI social media co-pilot built for Stars of Science.
                    Predict virality, decode algorithms, and reach 2.3M+ passionate science enthusiasts.
                  </p>
                </motion.div>

                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.35 }}
                  className="flex items-center gap-4 mb-10"
                >
                  <button
                    onClick={handleLaunch}
                    className="flex items-center gap-2.5 px-7 py-4 rounded-2xl transition-all duration-200 hover:scale-105 hover:shadow-2xl"
                    style={{
                      background: "linear-gradient(135deg, #3b82f6 0%, #8b5cf6 100%)",
                      boxShadow: "0 0 30px rgba(59, 130, 246, 0.4)",
                      fontFamily: "Outfit, sans-serif",
                      fontSize: 16,
                      fontWeight: 700,
                      color: "#fff",
                    }}
                  >
                    <Zap className="w-5 h-5" />
                    Begin Mission
                    <ArrowRight className="w-5 h-5" />
                  </button>
                  <button
                    className="flex items-center gap-2 px-6 py-4 rounded-2xl transition-all duration-200"
                    style={{
                      background: "rgba(255,255,255,0.04)",
                      border: "1px solid rgba(255,255,255,0.1)",
                      fontFamily: "Outfit, sans-serif",
                      fontSize: 15,
                      fontWeight: 500,
                      color: "#94a3b8",
                    }}
                  >
                    Watch Demo
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </motion.div>

                {/* Stats */}
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.5 }}
                  className="grid grid-cols-4 gap-4"
                >
                  {STATS.map((s) => (
                    <div key={s.label}>
                      <div
                        style={{
                          fontFamily: "Outfit, sans-serif",
                          fontSize: 24,
                          fontWeight: 800,
                          color: "#e2e8f0",
                          letterSpacing: "-0.02em",
                        }}
                      >
                        {s.value}
                      </div>
                      <div
                        style={{
                          fontFamily: "JetBrains Mono, monospace",
                          fontSize: 10,
                          color: "#475569",
                          letterSpacing: "0.05em",
                          marginTop: 2,
                        }}
                      >
                        {s.label.toUpperCase()}
                      </div>
                    </div>
                  ))}
                </motion.div>
              </div>

              {/* Globe */}
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.3, duration: 0.8 }}
                className="flex-1 flex items-center justify-center"
                style={{ height: "min(520px, 60vh)" }}
              >
                <div className="w-full h-full relative">
                  <div
                    className="absolute inset-0 rounded-full"
                    style={{
                      background: "radial-gradient(ellipse at center, rgba(59,130,246,0.08) 0%, transparent 70%)",
                      transform: "scale(1.3)",
                    }}
                  />
                  <GlobeViewer />
                </div>
              </motion.div>
            </div>

            {/* Module cards */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.6 }}
              className="px-8 pb-8"
            >
              <div className="grid grid-cols-6 gap-3">
                {MODULES.map((mod, i) => {
                  const Icon = mod.icon;
                  return (
                    <motion.div
                      key={mod.label}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: 0.6 + i * 0.07 }}
                      whileHover={{ y: -4, scale: 1.02 }}
                      className="p-4 rounded-2xl cursor-pointer transition-all duration-200"
                      style={{
                        background: "rgba(10, 22, 40, 0.7)",
                        border: "1px solid rgba(59, 130, 246, 0.12)",
                        backdropFilter: "blur(12px)",
                      }}
                    >
                      <div
                        className="w-9 h-9 rounded-xl flex items-center justify-center mb-3"
                        style={{ background: `${mod.color}18`, border: `1px solid ${mod.color}30` }}
                      >
                        <Icon className="w-4.5 h-4.5" style={{ color: mod.color }} />
                      </div>
                      <div
                        style={{
                          fontFamily: "Outfit, sans-serif",
                          fontSize: 12,
                          fontWeight: 700,
                          color: "#e2e8f0",
                          lineHeight: 1.3,
                          marginBottom: 4,
                        }}
                      >
                        {mod.label}
                      </div>
                      <div
                        style={{
                          fontFamily: "Outfit, sans-serif",
                          fontSize: 11,
                          color: "#475569",
                          lineHeight: 1.4,
                        }}
                      >
                        {mod.desc}
                      </div>
                    </motion.div>
                  );
                })}
              </div>
            </motion.div>
          </motion.div>
        )}

        {step === "onboarding" && (
          <motion.div
            key="onboarding"
            initial={{ opacity: 0, scale: 0.96 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0 }}
            className="relative z-10 w-full h-full flex items-center justify-center"
          >
            <div
              className="w-full max-w-lg mx-auto rounded-3xl p-8"
              style={{
                background: "rgba(10, 22, 40, 0.85)",
                border: "1px solid rgba(59, 130, 246, 0.2)",
                backdropFilter: "blur(24px)",
                boxShadow: "0 0 80px rgba(59, 130, 246, 0.1)",
              }}
            >
              {/* Progress */}
              <div className="flex items-center gap-2 mb-8">
                {onboardSteps.map((_, i) => (
                  <div
                    key={i}
                    className="h-0.5 flex-1 rounded-full transition-all duration-500"
                    style={{
                      background: i <= onboardStep ? "linear-gradient(90deg, #3b82f6, #8b5cf6)" : "rgba(59,130,246,0.15)",
                    }}
                  />
                ))}
              </div>

              <div
                className="mb-1"
                style={{ fontFamily: "JetBrains Mono, monospace", fontSize: 10, color: "#3b82f6", letterSpacing: "0.15em" }}
              >
                STEP {onboardStep + 1} OF {onboardSteps.length}
              </div>
              <h2
                style={{
                  fontFamily: "Outfit, sans-serif",
                  fontSize: 26,
                  fontWeight: 800,
                  color: "#e2e8f0",
                  letterSpacing: "-0.02em",
                  marginBottom: 4,
                  lineHeight: 1.2,
                }}
              >
                {onboardSteps[onboardStep].title}
              </h2>
              <p
                className="mb-8"
                style={{ fontFamily: "Outfit, sans-serif", fontSize: 14, color: "#64748b" }}
              >
                {onboardSteps[onboardStep].subtitle}
              </p>

              <AnimatePresence mode="wait">
                <motion.div
                  key={onboardStep}
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  transition={{ duration: 0.25 }}
                >
                  {onboardSteps[onboardStep].content}
                </motion.div>
              </AnimatePresence>

              <div className="flex items-center gap-3 mt-8">
                {onboardStep > 0 && (
                  <button
                    onClick={() => setOnboardStep((s) => s - 1)}
                    className="flex-1 py-3.5 rounded-xl transition-all"
                    style={{
                      background: "rgba(255,255,255,0.04)",
                      border: "1px solid rgba(255,255,255,0.08)",
                      fontFamily: "Outfit, sans-serif",
                      fontSize: 15,
                      fontWeight: 600,
                      color: "#64748b",
                    }}
                  >
                    Back
                  </button>
                )}
                <button
                  onClick={() => {
                    if (onboardStep < onboardSteps.length - 1) {
                      setOnboardStep((s) => s + 1);
                    } else {
                      handleLaunch();
                    }
                  }}
                  disabled={loading}
                  className="flex-[2] flex items-center justify-center gap-2 py-3.5 rounded-xl transition-all duration-200 hover:scale-[1.02]"
                  style={{
                    background: "linear-gradient(135deg, #3b82f6 0%, #8b5cf6 100%)",
                    boxShadow: "0 0 24px rgba(59, 130, 246, 0.35)",
                    fontFamily: "Outfit, sans-serif",
                    fontSize: 15,
                    fontWeight: 700,
                    color: "#fff",
                    opacity: loading ? 0.7 : 1,
                  }}
                >
                  {loading ? (
                    <>
                      <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                      Initializing...
                    </>
                  ) : onboardStep < onboardSteps.length - 1 ? (
                    <>
                      Continue
                      <ArrowRight className="w-4 h-4" />
                    </>
                  ) : (
                    <>
                      <Zap className="w-4 h-4" />
                      Launch Mission Control
                    </>
                  )}
                </button>
              </div>

              {onboardStep === 0 && (
                <button
                  onClick={onEnter}
                  className="w-full mt-3 text-center transition-colors"
                  style={{ fontFamily: "Outfit, sans-serif", fontSize: 13, color: "#475569" }}
                >
                  Skip setup → Enter with demo data
                </button>
              )}
            </div>

            {/* Metrics floating */}
            <div className="absolute top-1/4 right-8 hidden xl:flex flex-col gap-3">
              {[
                { label: "TOTAL REACH", value: "2.3M", trend: "+18%" },
                { label: "AVG ENGAGEMENT", value: "8.4%", trend: "+2.1%" },
                { label: "VIRAL SCORE", value: "87/100", trend: "↑" },
              ].map((m) => (
                <motion.div
                  key={m.label}
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  className="px-4 py-3 rounded-xl"
                  style={{
                    background: "rgba(10, 22, 40, 0.8)",
                    border: "1px solid rgba(59, 130, 246, 0.15)",
                    backdropFilter: "blur(12px)",
                    minWidth: 160,
                  }}
                >
                  <div style={{ fontFamily: "JetBrains Mono, monospace", fontSize: 9, color: "#64748b", letterSpacing: "0.1em" }}>{m.label}</div>
                  <div className="flex items-end gap-2 mt-1">
                    <span style={{ fontFamily: "Outfit, sans-serif", fontSize: 22, fontWeight: 800, color: "#e2e8f0" }}>{m.value}</span>
                    <span style={{ fontFamily: "JetBrains Mono, monospace", fontSize: 11, color: "#10b981", marginBottom: 3 }}>{m.trend}</span>
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Scan line effect */}
      <div
        className="absolute inset-x-0 pointer-events-none"
        style={{
          height: 1,
          background: "linear-gradient(90deg, transparent 0%, rgba(59,130,246,0.3) 50%, transparent 100%)",
          animation: "scanline 8s linear infinite",
          top: 0,
          zIndex: 20,
        }}
      />
      <style>{`
        @keyframes scanline {
          from { top: 0; opacity: 0.7; }
          to { top: 100%; opacity: 0.3; }
        }
      `}</style>
    </div>
  );
}
